import os

def create_report():
    doc_path = "/Users/priyadarshanasilva/.gemini/antigravity/scratch/SunriseDentalClinic/Sunrise_Dental_Clinic_Coursework_Report.doc"
    md_path = "/Users/priyadarshanasilva/.gemini/antigravity/scratch/SunriseDentalClinic/DOCUMENTATION.md"

    # HTML / Word styling
    html_content = """<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
<head>
<meta charset="utf-8">
<title>CIS6003 Advanced Programming - Sunrise Dental Clinic Management System</title>
<!--[if gte mso 9]>
<xml>
 <w:WordDocument>
  <w:View>Print</w:View>
  <w:Zoom>100</w:Zoom>
  <w:DoNotOptimizeForBrowser/>
 </w:WordDocument>
</xml>
<![endif]-->
<style>
@page {
    size: A4;
    margin: 1.0in 1.0in 1.0in 1.5in;
    mso-header-margin: 0.5in;
    mso-footer-margin: 0.5in;
    mso-paper-source: 0;
}
div.Section1 {
    page: Section1;
}
body {
    font-family: 'Times New Roman', Times, serif;
    font-size: 12pt;
    line-height: 1.5;
    color: #000000;
}
h1 {
    font-size: 18pt;
    font-weight: bold;
    text-align: center;
    margin-top: 24pt;
    margin-bottom: 12pt;
    page-break-before: always;
}
h2 {
    font-size: 14pt;
    font-weight: bold;
    margin-top: 18pt;
    margin-bottom: 8pt;
    border-bottom: 1px solid #cccccc;
    padding-bottom: 4pt;
}
h3 {
    font-size: 13pt;
    font-weight: bold;
    margin-top: 14pt;
    margin-bottom: 6pt;
}
h4 {
    font-size: 12pt;
    font-weight: bold;
    font-style: italic;
    margin-top: 10pt;
    margin-bottom: 4pt;
}
p {
    margin-top: 0pt;
    margin-bottom: 8pt;
    text-align: justify;
}
.page-break {
    page-break-before: always;
}
table.cover-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15pt;
    margin-bottom: 15pt;
}
table.cover-table td, table.cover-table th {
    border: 1px solid #000000;
    padding: 6pt 10pt;
    font-size: 11pt;
}
table.cover-table th {
    background-color: #000000;
    color: #ffffff;
    font-weight: bold;
    text-align: left;
}
table.custom-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10pt;
    margin-bottom: 12pt;
}
table.custom-table th, table.custom-table td {
    border: 1px solid #999999;
    padding: 6pt 8pt;
    font-size: 10.5pt;
}
table.custom-table th {
    background-color: #e2e8f0;
    font-weight: bold;
    text-align: left;
}
table.test-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 8pt;
    margin-bottom: 16pt;
}
table.test-table td, table.test-table th {
    border: 1px solid #718096;
    padding: 5pt 8pt;
    font-size: 10pt;
}
table.test-table th {
    background-color: #ebf8ff;
    color: #2b6cb0;
    font-weight: bold;
}
.test-header {
    background-color: #bee3f8;
    color: #2c5282;
    font-weight: bold;
}
.badge-pass {
    background-color: #c6f6d5;
    color: #22543d;
    font-weight: bold;
    padding: 2px 6px;
    border-radius: 3px;
    border: 1px solid #9ae6b4;
}
.diagram-box {
    border: 2px solid #2b6cb0;
    background-color: #f7fafc;
    padding: 15pt;
    margin: 12pt 0;
    font-family: 'Courier New', Courier, monospace;
    font-size: 9.5pt;
    white-space: pre-wrap;
    border-radius: 4px;
}
.code-box {
    background-color: #1a202c;
    color: #edf2f7;
    padding: 12pt;
    margin: 10pt 0;
    font-family: 'Courier New', Courier, monospace;
    font-size: 9pt;
    border-radius: 4px;
    white-space: pre-wrap;
}
.ui-mock-box {
    border: 1px solid #cbd5e0;
    background-color: #edf2f7;
    padding: 12pt;
    text-align: center;
    margin: 10pt 0;
    font-style: italic;
    color: #4a5568;
}
.declaration-box {
    border: 1px solid #000000;
    padding: 10pt;
    margin-top: 15pt;
}
</style>
</head>
<body>
<div class="Section1">

<!-- ======================================================== -->
<!-- PAGE 1: COVER SHEET -->
<!-- ======================================================== -->
<div style="text-align: center; margin-top: 20pt;">
    <h2 style="border: none; margin-bottom: 2pt; font-size: 16pt; text-transform: uppercase;">Cardiff Metropolitan University</h2>
    <h3 style="margin-top: 0; font-size: 14pt; color: #2b6cb0;">B.Sc. (Hons) in Software Engineering</h3>
    <h4 style="margin-top: 4pt; font-size: 13pt; text-decoration: underline;">Assignment Cover Sheet</h4>
</div>

<table class="cover-table">
    <tr>
        <th colspan="2">Student Details (Student should fill the content)</th>
    </tr>
    <tr>
        <td style="width: 35%;"><strong>Name</strong></td>
        <td>D. P. Udara Marasinghe</td>
    </tr>
    <tr>
        <td><strong>Student ID</strong></td>
        <td>st20311784 / CL/BSCSD/33/44</td>
    </tr>
    <tr>
        <th colspan="2">Scheduled Unit Details</th>
    </tr>
    <tr>
        <td><strong>Unit Code</strong></td>
        <td>CIS6003</td>
    </tr>
    <tr>
        <td><strong>Unit Title</strong></td>
        <td>Advanced Programming</td>
    </tr>
    <tr>
        <td><strong>Unit Enrolment Details</strong></td>
        <td>Year 3 &nbsp;&nbsp;|&nbsp;&nbsp; Semester 1 &nbsp;&nbsp;|&nbsp;&nbsp; Academic Year 2024</td>
    </tr>
    <tr>
        <td><strong>Lecturer / Module Leader</strong></td>
        <td>Mr. Priyanga Jayawardena</td>
    </tr>
    <tr>
        <td><strong>Mode of Delivery</strong></td>
        <td>Full Time</td>
    </tr>
    <tr>
        <th colspan="2">Assignment Details</th>
    </tr>
    <tr>
        <td><strong>Nature of the Assessment</strong></td>
        <td>Written Report & Practical Software Development (WRIT1 - 100%)</td>
    </tr>
    <tr>
        <td><strong>Topic of the Case Study</strong></td>
        <td><strong>Advanced Programming – Sunrise Dental Clinic Management System</strong></td>
    </tr>
    <tr>
        <td><strong>Word Count</strong></td>
        <td>4000 words (excluding appendices and references)</td>
    </tr>
    <tr>
        <td><strong>Due Date / Time</strong></td>
        <td>Standard Scheduled Submission Date</td>
    </tr>
</table>

<div class="declaration-box">
    <strong style="text-decoration: underline;">Declaration:</strong><br>
    I certify that the attached material is my original work. No other person’s work or ideas have been used without acknowledgement. Except where I have clearly stated that I have used some of this material elsewhere, I have not presented it for examination / assessment in any other course or unit at this or any other institution.
    <br><br>
    <table style="width: 100%; border: none; margin-top: 10pt;">
        <tr>
            <td style="border: none; width: 60%;"><strong>Name/Signature:</strong> D. P. Udara Marasinghe</td>
            <td style="border: none; width: 40%;"><strong>Date:</strong> 07-March-2026</td>
        </tr>
    </table>
</div>

<div class="page-break"></div>

<!-- ======================================================== -->
<!-- PAGE 2: ACKNOWLEDGMENTS -->
<!-- ======================================================== -->
<h1>Acknowledgment</h1>
<p>
I would like to express my sincere gratitude and appreciation to everyone who supported me throughout the design, development, and compilation of this Advanced Programming (CIS6003) assignment based on the <strong>Sunrise Dental Clinic Patient and Appointment Management System</strong>.
</p>
<p>
First and foremost, I convey my deepest respect and thankfulness to our module leader and lecturer, Mr. Priyanga Jayawardena, for his invaluable guidance, insightful lecture sessions, constructive feedback, and academic supervision. His lectures on object-oriented software engineering, distributed computing with web services, architectural tiering, and advanced database integration provided the intellectual foundation necessary to complete this extensive coursework.
</p>
<p>
I also extend my sincere appreciation to the academic and laboratory staff of ICBT Campus and Cardiff Metropolitan University for maintaining world-class development environments, library subscriptions, and academic resources that facilitated this work. Finally, I am profoundly grateful to my family and colleagues for their constant encouragement, moral support, and patience throughout this endeavor.
</p>

<div class="page-break"></div>

<!-- ======================================================== -->
<!-- PAGE 3: EXECUTIVE SUMMARY -->
<!-- ======================================================== -->
<h1>Executive Summary</h1>
<p>
This report presents the complete software engineering analysis, architectural design, implementation, test-driven validation, and version-controlled deployment of a distributed enterprise appointment and patient management solution for <strong>Sunrise Dental Clinic</strong> in Colombo, Sri Lanka.
</p>
<p>
Historically, Sunrise Dental Clinic has operated under manual record-keeping utilizing paper diaries, ledger books, and physical patient file cabinets. As patient volumes expanded, this archaic methodology produced grave operational bottlenecks, including inadvertent double-booking of specialist dental surgeons, lost clinical and history records, prolonged patient waiting queues, and manual billing and calculation discrepancies. To resolve these systemic deficiencies, clinic management commissioned the development of a modern, automated, and secure software system.
</p>
<p>
The developed solution is engineered in strict compliance with the Cardiff Metropolitan University CIS6003 Level 6 learning outcomes:
</p>
<ul>
    <li><strong>Task A (System Design with UML):</strong> Formulates high-level and detailed architectural models, including a comprehensive Use Case Diagram (with <code>&lt;&lt;include&gt;&gt;</code> and <code>&lt;&lt;extend&gt;&gt;</code> stereotypes), a robust Class Diagram (exhibiting visibility modifiers, multiplicity, aggregation, and composition), and six granular Sequence Diagrams visualizing interaction lifelines across core system workflows.</li>
    <li><strong>Task B (System Architecture & Development):</strong> Constructs an interactive, distributed application adhering to a <strong>Three-Tier Architecture</strong> (Presentation, Business Logic, and Data Access Layers). It exposes distributed <strong>RESTful Web Services</strong>, integrates session and cookie state management, and implements four industry-standard Design Patterns: <strong>Singleton</strong>, <strong>Factory Method</strong>, <strong>Strategy</strong>, and <strong>Observer</strong>. The persistence layer leverages an advanced <strong>MySQL</strong> database utilizing Stored Procedures (enforcing transactional safety), Database Triggers (guaranteeing physical double-booking prevention), and Analytical Views (driving decision-support reporting).</li>
    <li><strong>Task C (Testing & Test-Driven Development):</strong> Details a disciplined TDD methodology and comprehensive test plan with over 25 automated and manual test cases covering functional boundaries, equivalence classes, and security rules, backed by automated <strong>JUnit 5</strong> test classes.</li>
    <li><strong>Task D (Version Control & CI/CD Workflows):</strong> Demonstrates progressive multi-day version control through a public GitHub repository, branching workflows (feature branches and merge commits), and an automated <strong>GitHub Actions CI/CD pipeline</strong> validating automated builds and test suites on push.</li>
</ul>

<div class="page-break"></div>

<!-- ======================================================== -->
<!-- PAGE 4: TABLE OF CONTENTS -->
<!-- ======================================================== -->
<h1>Table of Contents</h1>
<table class="custom-table" style="border: none;">
    <tr style="border-bottom: 2px solid #000000;"><th style="background: none; border: none;">Section / Topic</th><th style="background: none; border: none; text-align: right; width: 15%;">Page</th></tr>
    <tr><td style="border: none;"><strong>Acknowledgment</strong></td><td style="border: none; text-align: right;">2</td></tr>
    <tr><td style="border: none;"><strong>Executive Summary</strong></td><td style="border: none; text-align: right;">3</td></tr>
    <tr><td style="border: none;"><strong>1. Introduction & Case Study Background</strong></td><td style="border: none; text-align: right;">5</td></tr>
    <tr><td style="border: none;"><strong>2. TASK A: System Design with UML Diagrams</strong></td><td style="border: none; text-align: right;">6</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">2.1 Class Diagram Theory & Access Modifiers</td><td style="border: none; text-align: right;">6</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">2.2 Assumptions on the Class Diagram</td><td style="border: none; text-align: right;">7</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">2.3 Class Diagram Specification & Structure</td><td style="border: none; text-align: right;">8</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">2.4 Justification of Class Diagram Relationships</td><td style="border: none; text-align: right;">9</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">2.5 Use Case Diagram Theory & Stereotypes</td><td style="border: none; text-align: right;">10</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">2.6 Use Case Diagram Model & Assumptions</td><td style="border: none; text-align: right;">11</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">2.7 Justification of Use Cases & Relationships</td><td style="border: none; text-align: right;">12</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">2.8 Sequence Diagrams (Core System Lifelines)</td><td style="border: none; text-align: right;">13</td></tr>
    <tr><td style="border: none;"><strong>3. TASK B: Architecture & Software Engineering Principles</strong></td><td style="border: none; text-align: right;">18</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">3.1 Three-Tier Architecture (Advantages & Disadvantages)</td><td style="border: none; text-align: right;">18</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">3.2 Presentation Tier Implementation</td><td style="border: none; text-align: right;">20</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">3.3 Application / Business Logic Tier Implementation</td><td style="border: none; text-align: right;">22</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">3.4 Data Tier & Advanced Database Features</td><td style="border: none; text-align: right;">24</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">3.5 Object-Oriented Programming (OOP) Principles Applied</td><td style="border: none; text-align: right;">26</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">3.6 Software Design Patterns Applied (4 Core Patterns)</td><td style="border: none; text-align: right;">30</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">3.7 SOLID Principles Analysis & Verification</td><td style="border: none; text-align: right;">34</td></tr>
    <tr><td style="border: none;"><strong>4. TASK C: Test-Driven Development (TDD) & Test Automation</strong></td><td style="border: none; text-align: right;">37</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">4.1 TDD Rationale & Automation Framework</td><td style="border: none; text-align: right;">37</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">4.2 Master Test Plan & Traceability Matrix</td><td style="border: none; text-align: right;">38</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">4.3 Detailed Test Cases (Test Cards 01 - 25)</td><td style="border: none; text-align: right;">40</td></tr>
    <tr><td style="border: none;"><strong>5. TASK D: Git Version Control & CI/CD Deployment</strong></td><td style="border: none; text-align: right;">65</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">5.1 GitHub Repository Setup & Multi-Day Commits</td><td style="border: none; text-align: right;">65</td></tr>
    <tr><td style="border: none; padding-left: 20pt;">5.2 Automated CI/CD Pipeline Deployment</td><td style="border: none; text-align: right;">67</td></tr>
    <tr><td style="border: none;"><strong>6. References</strong></td><td style="border: none; text-align: right;">68</td></tr>
</table>

<div class="page-break"></div>

<!-- ======================================================== -->
<!-- SECTION 1: INTRODUCTION -->
<!-- ======================================================== -->
<h1>1. Introduction & Case Study Background</h1>
<p>
Modern healthcare and dental care institutions operate in high-throughput environments where patient scheduling accuracy, medical treatment histories, and transparent financial billing are critical to service quality and operational survival. <strong>Sunrise Dental Clinic</strong> is a prominent, busy private dental center located in Colombo, Sri Lanka, providing specialized dental care services including general cleaning, orthodontic alignments, endodontic root canal treatments, restorative fillings, and oral surgical extractions to hundreds of patients weekly.
</p>
<p>
Despite having highly skilled consultant dental surgeons, Sunrise Dental Clinic has suffered severely from operational inefficiencies stemming from legacy, manual paperwork practices:
</p>
<ul>
    <li><strong>Double-Booking of Specialized Surgeries:</strong> Front-desk receptionists recording appointments across physical paper diaries regularly assign two patients to the same dentist during identical clinical time slots, causing patient dissatisfaction and doctor frustration.</li>
    <li><strong>Lost Patient Medical Records:</strong> Physical patient folders stored in filing cabinets are frequently misplaced, damaged, or delayed in transit between reception and surgical operatories.</li>
    <li><strong>Prolonged Waiting Times:</strong> Inaccurate tracking of appointment schedules leads to clinic lobby congestion and excessive waiting times for registered patients.</li>
    <li><strong>Billing & Calculation Discrepancies:</strong> Financial calculations—combining diverse treatment fees, doctor consultation charges, taxation, senior citizen discounts, and insurance co-payments—are manually computed on paper slips, leading to frequent mathematical errors and revenue loss.</li>
</ul>
<p>
To permanently overcome these operational challenges, this project develops a robust, enterprise-grade, distributed <strong>Computerized Appointment and Patient Management System</strong> built with Java, modern REST Web Services, a Three-Tier architecture, and an advanced MySQL relational database engine.
</p>

<div class="page-break"></div>

<!-- ======================================================== -->
<!-- SECTION 2: TASK A - SYSTEM DESIGN WITH UML -->
<!-- ======================================================== -->
<h1>2. TASK A: System Design with UML Diagrams</h1>

<h2>2.1 What is a Class Diagram?</h2>
<p>
A <strong>Class Diagram</strong> is a static structural diagram in the Unified Modeling Language (UML) that describes the structure of a system by displaying its classes, attributes, methods/operations, and the static relationships among objects (Visual Paradigm, 2024). Class diagrams form the structural backbone of object-oriented systems by translating domain requirements into concrete architectural entities.
</p>
<p>
In object-oriented design, member accessibility is governed by <strong>Access Modifiers</strong> (GeeksforGeeks, 2025b):
</p>
<ul>
    <li><strong>Private (<code>-</code>):</strong> Attributes or methods are accessible exclusively within the encapsulating class. This protects sensitive data members (e.g., password hashes, patient private addresses, financial calculations) from uncontrolled external mutation.</li>
    <li><strong>Public (<code>+</code>):</strong> Methods or members are accessible from any component across the software system, establishing well-defined operational interfaces (e.g., <code>bookAppointment()</code>, <code>calculateBill()</code>).</li>
    <li><strong>Protected (<code>#</code>):</strong> Accessible within the class, package, and by derived subclasses.</li>
</ul>

<h2>2.2 Assumptions Made on the Class Diagram</h2>
<ul>
    <li>Every patient visit is registered under a uniquely assigned, system-generated alphanumeric appointment number (e.g., <code>APT-YYYYMMDD-XXXX</code>).</li>
    <li>A patient can have multiple appointments over time, but each specific appointment instance links to exactly one patient, one consulting dentist, and one primary dental treatment procedure.</li>
    <li>Dentist consultation fees are configured individually based on their clinical specialty, and treatment base costs are maintained in a central catalog.</li>
    <li>An appointment generates exactly one final financial Bill record upon completion.</li>
    <li>A thread-safe Singleton database manager ensures a single point of database connectivity throughout the application lifecycle.</li>
</ul>

<h2>2.3 Class Diagram Specification & Structural Model</h2>
<p>
The structural model for the Sunrise Dental Clinic Management System consists of six primary domain entities, specialized factory and strategy interfaces, and DAO persistence components:
</p>

<div class="diagram-box">
+-----------------------------------------------------------------------------------+
|                                  CLASS DIAGRAM                                    |
|                      Sunrise Dental Clinic Management System                      |
+-----------------------------------------------------------------------------------+

 +-------------------------+              +-------------------------+
 |          User           |              |         Patient         |
 +-------------------------+              +-------------------------+
 | - id: int               |              | - id: int               |
 | - username: String      |              | - patientName: String   |
 | - passwordHash: String  |              | - address: String       |
 | - fullName: String      |              | - contactNumber: String |
 | - role: String          |              | - email: String         |
 | - isActive: boolean     |              | - createdAt: Timestamp  |
 +-------------------------+              +-------------------------+
 | + authenticate(): bool  |              | + getDetails(): String  |
 | + getRole(): String     |              | + updateContact(): void |
 +-------------------------+              +-------------------------+
              ^                                        ^
              | manages                                | 1
              |                                        | books
              | 1..*                                   | 1..*
 +-------------------------------------------------------------------+
 |                            Appointment                            |
 +-------------------------------------------------------------------+
 | - id: int                                                         |
 | - appointmentNumber: String {Unique}                              |
 | - patientId: int                                                  |
 | - dentistId: int                                                  |
 | - treatmentId: int                                                |
 | - appointmentDate: LocalDate                                      |
 | - appointmentTime: LocalTime                                      |
 | - status: String                                                  |
 | - notes: String                                                   |
 +-------------------------------------------------------------------+
 | + checkConflict(dentistId, date, time): boolean                   |
 | + confirmBooking(): void                                          |
 | + cancelAppointment(): void                                       |
 | + markBilled(): void                                              |
 +-------------------------------------------------------------------+
       | 1..*                                         | 1..*
       | scheduled with                               | treated by
       v 1                                            v 1
 +-------------------------+              +-------------------------+
 |        Treatment        |              |         Dentist         |
 +-------------------------+              +-------------------------+
 | - id: int               |              | - id: int               |
 | - treatmentName: String |              | - name: String          |
 | - description: String   |              | - specialization: String|
 | - baseCost: BigDecimal  |              | - consultationFee: Dec  |
 | - durationMinutes: int  |              | - contactNumber: String |
 +-------------------------+              +-------------------------+
 | + getBaseCost(): Dec    |              | + isAvailable(): bool   |
 +-------------------------+              +-------------------------+
              |                                        |
              +-------------------+--------------------+
                                  | 1
                                  | generates
                                  v 1
                     +---------------------------+
                     |           Bill            |
                     +---------------------------+
                     | - id: int                 |
                     | - billNumber: String      |
                     | - appointmentId: int      |
                     | - treatmentCost: Dec      |
                     | - consultationFee: Dec    |
                     | - discountAmount: Dec     |
                     | - totalAmount: Dec        |
                     | - paymentMethod: String   |
                     | - paymentStatus: String   |
                     +---------------------------+
                     | + calculateTotal(): Dec   |
                     | + printReceipt(): void    |
                     +---------------------------+
</div>

<h2>2.4 Justification of Class Diagram Relationships</h2>
<ul>
    <li><strong>Patient to Appointment (1 to 1..* Association):</strong> A registered patient can book multiple dental appointments over their medical lifetime. However, an individual appointment belongs strictly to one unique patient. Without a patient entity, an appointment cannot exist.</li>
    <li><strong>Dentist to Appointment (1 to 0..* Association):</strong> A specialist dental surgeon can be scheduled across multiple distinct appointments, but an appointment can only be assigned to a single attending dentist. The system checks this association to guarantee no double-booking occurs.</li>
    <li><strong>Treatment to Appointment (1 to 1..* Association):</strong> Every appointment targets a specific clinical procedure (e.g., Root Canal, Cleaning, Extraction) chosen from the standard treatment catalog.</li>
    <li><strong>Appointment to Bill (1 to 1 Composition):</strong> Once clinical procedures are completed, an appointment transitions to billing. A Bill record cannot exist without a preceding appointment reference, representing a strict composition lifecycle.</li>
</ul>

<div class="page-break"></div>

<h2>2.5 What is a Use Case Diagram?</h2>
<p>
A <strong>Use Case Diagram</strong> is a behavioral UML diagram that models how system users (actors) interact with an application to achieve distinct, measurable functional goals (GeeksforGeeks, 2026). It establishes functional boundaries and illustrates behavioral extensions and dependencies:
</p>
<ul>
    <li><strong><code>&lt;&lt;include&gt;&gt;</code> Stereotype:</strong> Denotes a mandatory dependency where the base use case explicitly invokes the included use case. Execution of the base use case cannot complete without executing the included behavior (e.g., booking an appointment <em>includes</em> verifying dentist slot availability).</li>
    <li><strong><code>&lt;&lt;extend&gt;&gt;</code> Stereotype:</strong> Denotes an optional or conditional behavior that augments the base use case under specific trigger conditions (e.g., applying senior citizen or insurance discounts when calculating a bill).</li>
</ul>

<h2>2.6 Use Case Diagram Model & Assumptions</h2>

<div class="diagram-box">
+-----------------------------------------------------------------------------------+
|                               USE CASE DIAGRAM                                    |
|                      Sunrise Dental Clinic Management System                      |
+-----------------------------------------------------------------------------------+

     [ ACTORS ]                                 [ SYSTEM BOUNDARY ]

                               +--------------------------------------------+
                               |                                            |
                               |  ( User Login ) <-----------+              |
                               |         ^                   |              |
                               |         | <<include>>       |              |
                               |  ( Verify Credentials )     |              |
                               |         ^                   |              |
                               |         | <<extend>>        |              |
                               |  ( Invalid Credentials )    |              |
                               |                             |              |
     +--------------+          |  ( Register Appointment ) --+              |
     | Receptionist | -------->|         |                   |              |
     +--------------+          |         | <<include>>       |              |
            |                  |         v                   |              |
            |                  |  ( Check Slot Availability )|              |
            |                  |         | <<extend>>        |              |
            |                  |  ( Double Booking Alert )   |              |
            |                  |                             |              |
            |                  |  ( Search Appointment ) ----+              |
            |                  |                             |              |
            |                  |  ( Calculate Bill ) --------+              |
            |                  |         |                   |              |
            |                  |         | <<extend>>        |              |
            |                  |  ( Apply Senior/Insurance   |              |
            |                  |         Discount )          |              |
            |                  |         |                   |              |
            |                  |         | <<include>>       |              |
            |                  |  ( Print Receipt )          |              |
            |                  |                             |              |
            |                  |  ( View Help Guide )        |              |
            |                  |  ( Logout / Exit )          |              |
            |                  |                                            |
     +--------------+          |  ( View Daily Summary )     |              |
     |    Admin     | -------->|  ( View Revenue Analytics ) |              |
     +--------------+          |                                            |
            |                  +--------------------------------------------+
     +--------------+
     |   Dentist    | --------> ( View Assigned Appointments )
     +--------------+
</div>

<h3>Assumptions Made on Use Case Diagram:</h3>
<ul>
    <li>Only authorized staff members who successfully authenticate can access operational use cases.</li>
    <li>The Front-Desk Receptionist is the primary operator responsible for registering appointments, searching patient visits, and finalizing payment receipts.</li>
    <li>Administrators hold elevated rights allowing generation of clinic revenue and doctor performance reports.</li>
</ul>

<h2>2.7 Justification of Use Cases & Relationships</h2>
<ul>
    <li><strong><code>User Login &lt;&lt;include&gt;&gt; Verify Credentials</code>:</strong> For access security, any login attempt must trigger mandatory cryptographic credential verification against the database.</li>
    <li><strong><code>Register Appointment &lt;&lt;include&gt;&gt; Check Slot Availability</code>:</strong> Prevents human error by forcing an automatic query to verify the dentist's schedule before saving an appointment.</li>
    <li><strong><code>Register Appointment &lt;&lt;extend&gt;&gt; Double-Booking Conflict Alert</code>:</strong> If the slot is already occupied, the system conditionally branches to an alert state, preventing concurrent booking.</li>
    <li><strong><code>Calculate Bill &lt;&lt;extend&gt;&gt; Apply Senior/Insurance Discount</code>:</strong> The standard billing workflow conditionally executes discount calculations when patient qualifies for concessionary rates.</li>
    <li><strong><code>Calculate Bill &lt;&lt;include&gt;&gt; Print Receipt</code>:</strong> Every completed payment generates an official printed tax receipt for patient records.</li>
</ul>

<div class="page-break"></div>

<h2>2.8 Sequence Diagrams (Core System Lifelines)</h2>
<p>
A <strong>Sequence Diagram</strong> models object interactions arranged in time sequence, depicting lifelines, asynchronous/synchronous messages, return signals, and control foci (Athuraliya and Creately, 2025b). Below are sequence lifelines for the six core processes:
</p>

<h3>1. User Authentication (Login Process)</h3>
<div class="diagram-box">
Staff                  Login UI             AuthController         AuthService              UserDAO               Database
  |                       |                       |                     |                      |                     |
  |--- 1. Enter username -|                       |                     |                      |                     |
  |       & password ---->|                       |                     |                      |                     |
  |                       |--- 2. POST /api/auth->|                     |                      |                     |
  |                       |        login JSON     |--- 3. authenticate->|                      |                     |
  |                       |                       |       (user, pass)  |--- 4. findByUsername>|                     |
  |                       |                       |                     |                      |--- 5. SQL SELECT--->|
  |                       |                       |                     |                      |<-- 6. User record---|
  |                       |                       |                     |<-- 7. User entity ---|                     |
  |                       |                       |                     |    8. Match hash     |                     |
  |                       |                       |<-- 9. Auth Success--|                      |                     |
  |                       |                       |    10. Set Cookie   |                      |                     |
  |                       |                       |    & HTTP Session   |                      |                     |
  |                       |<-- 11. 200 OK Token---|                     |                      |                     |
  |<-- 12. Dashboard View-|                       |                     |                      |                     |
</div>

<h3>2. Register New Appointment (with Double-Booking Conflict Prevention)</h3>
<div class="diagram-box">
Staff               Booking UI            ApptController        ApptService           ApptDAO                Database
  |                      |                      |                    |                   |                      |
  |-- 1. Fill details -> |                      |                    |                   |                      |
  |   (name, doc, time)  |                      |                    |                   |                      |
  |                      |-- 2. POST /api/appt->|                    |                   |                      |
  |                      |      (JSON Payload)  |-- 3. registerAppt->|                   |                      |
  |                      |                      |                    |-- 4. hasConflict->|                      |
  |                      |                      |                    |      (doc, date)  |-- 5. Query Count --->|
  |                      |                      |                    |                   |<-- 6. Count == 0 ----|
  |                      |                      |                    |<-- 7. No Conflict-|                      |
  |                      |                      |                    |-- 8. find/create->|-- 9. Insert Patient->|
  |                      |                      |                    |-- 10. insertAppt->|-- 11. Insert Appt--->|
  |                      |                      |                    |                   |<-- 12. APT-1001 -----|
  |                      |                      |                    |-- 13. Notify Observers (SMS & Email)---->|
  |                      |                      |<-- 14. 201 Created-|                   |                      |
  |                      |<-- 15. Success Alert-|                    |                   |                      |
  |<-- 16. Show Number --|                      |                    |                   |                      |
</div>

<h3>3. Search & Display Appointment Details</h3>
<div class="diagram-box">
Staff               Search UI             ApptController        ApptService           ApptDAO               Database
  |                      |                      |                    |                   |                     |
  |-- 1. Enter APT No.-->|                      |                    |                   |                     |
  |                      |-- 2. GET /api/appt/->|                    |                   |                     |
  |                      |      {aptNumber}     |-- 3. getDetails--->|                   |                     |
  |                      |                      |                    |-- 4. findByNumber>|                     |
  |                      |                      |                    |                   |-- 5. SELECT FROM -->|
  |                      |                      |                    |                   |      vw_complete_apt|
  |                      |                      |                    |                   |<-- 6. Full Row -----|
  |                      |                      |                    |<-- 7. Appt Model--|                     |
  |                      |                      |<-- 8. 200 OK (JSON)|                   |                     |
  |                      |<-- 9. Populate Card--|                    |                   |                     |
  |<-- 10. View Details--|                      |                    |                   |                     |
</div>

<h3>4. Calculate & Print Bill (Strategy Pattern Execution)</h3>
<div class="diagram-box">
Staff               Billing UI            BillController        BillingService        BillingStrategy       BillDAO
  |                      |                      |                    |                       |             |
  |-- 1. Enter APT No.-->|                      |                    |                       |             |
  |   & Select Strategy  |-- 2. POST /billing ->|                    |                       |             |
  |                      |      /generate       |-- 3. generateBill->|                       |             |
  |                      |                      |                    |-- 4. Calculate Total->|             |
  |                      |                      |                    |<-- 5. Itemized Result-|             |
  |                      |                      |                    |-- 6. saveBill() ------------------->|
  |                      |                      |                    |<-- 7. BILL-2024-01 -----------------|
  |                      |                      |                    |-- 8. Trigger SMS & Email Alert ---->|
  |                      |                      |<-- 9. 201 Created--|                                     |
  |                      |<-- 10. Render Receipt|                    |                                     |
  |-- 11. Click Print -->|                      |                    |                                     |
  |<-- 12. window.print()|                      |                    |                                     |
</div>

<h3>5. Help Section Workflow</h3>
<div class="diagram-box">
Staff                                    Help Navigation                                  System UI
  |                                             |                                             |
  |--- 1. Click 'Help Guide' Tab -------------->|                                             |
  |                                             |--- 2. Trigger showSection('help-section')-->|
  |                                             |                                             |--- 3. Render
  |                                             |                                             |    Accordion
  |<-- 4. View Step-by-Step Instructions -------|---------------------------------------------|
</div>

<h3>6. Logout / Session Termination Workflow</h3>
<div class="diagram-box">
Staff                                     Dashboard UI                                AuthController
  |                                             |                                            |
  |--- 1. Click 'Exit / Logout' --------------->|                                            |
  |                                             |--- 2. POST /api/auth/logout -------------->|
  |                                             |                                            |--- 3. session.invalidate()
  |                                             |                                            |--- 4. Clear sunrise_user cookie
  |                                             |<-- 5. 200 OK "Logged Out" -----------------|
  |                                             |--- 6. Clear local tokens & reset view ---->|
  |<-- 7. Redirect to Login Screen -------------|                                            |
</div>

<div class="page-break"></div>

<!-- ======================================================== -->
<!-- SECTION 3: TASK B - ARCHITECTURE & SOFTWARE PRINCIPLES -->
<!-- ======================================================== -->
<h1>3. TASK B: Architecture & Software Engineering Principles</h1>

<h2>3.1 What is Three-Tier Architecture?</h2>
<p>
A <strong>Three-Tier Software Architecture</strong> is a modular client-server software architecture pattern in which the functional process logic, data access, computer data storage, and user interface are developed and maintained as independent modules on separate layers (Gaxweb, 2024). The three distinct tiers comprise:
</p>
<ol>
    <li><strong>Presentation Tier (Front-End Client):</strong> Manages the graphical user interface (GUI) and translates user inputs into network requests.</li>
    <li><strong>Application Tier (Middle / Business Logic Tier):</strong> Coordinates application processing, performs data validations, executes business calculations, and implements design patterns.</li>
    <li><strong>Data Management Tier (Back-End Database):</strong> Manages data persistence, transactional integrity, stored procedures, triggers, and relational schemas.</li>
</ol>

<h3>Advantages of 3-Tier Architecture (GeeksforGeeks, 2021):</h3>
<ul>
    <li><strong>High Scalability:</strong> Application service tiers can be horizontally clustered across multiple servers without altering client code or database storage engines.</li>
    <li><strong>Enhanced Security:</strong> Presentation clients cannot interact directly with the database. The application middle tier enforces strict authentication, SQL injection shielding, and authorization barriers before persisting records.</li>
    <li><strong>Maintainability & Decoupling:</strong> Modifications made to the database schema or user interface do not cascade into breaking failures across the entire software application.</li>
    <li><strong>Reusability:</strong> Common business services (such as appointment conflict checking) can be consumed concurrently by web browsers, mobile applications, or third-party web services.</li>
</ul>

<h3>Disadvantages of 3-Tier Architecture:</h3>
<ul>
    <li><strong>Increased Architectural Complexity:</strong> Developing, configuring, and deploying multi-tiered distributed applications requires greater technical expertise than monolithic two-tier software.</li>
    <li><strong>Network Communication Overhead:</strong> Splitting services across distinct application and database tiers introduces minor network latency compared to collocated in-process memory calls.</li>
</ul>

<h2>3.2 Presentation Tier Implementation</h2>
<p>
In the Sunrise Dental Clinic system, the <strong>Presentation Layer</strong> is constructed as a decoupled, responsive single-page web interface utilizing HTML5, CSS3, JavaScript (ES6+), and Bootstrap 5. It manages:
</p>
<ul>
    <li>Asynchronous communications using standard <code>fetch()</code> REST APIs.</li>
    <li>Real-time client-side input validations (e.g., Sri Lankan telephone regex <code>^(0|\+94)[0-9]{9}$</code>, past date prevention).</li>
    <li>Dynamic fee preview calculations updating immediately when a user selects different dentists or treatments.</li>
    <li>Session and Cookie state management reflecting logged-in staff identities.</li>
    <li>Printable receipt view with specialized <code>@media print</code> formatting.</li>
</ul>

<div class="ui-mock-box">
[ FIGURE: Screenshot of Presentation Layer - Interactive Appointment Booking & Cost Estimation Interface ]<br>
File Reference: src/main/resources/static/index.html & app.js
</div>

<h2>3.3 Application / Business Logic Tier Implementation</h2>
<p>
The <strong>Application Tier</strong> is implemented in Java utilizing Spring Boot framework components. It coordinates:
</p>
<ul>
    <li><strong>Distributed REST Controllers:</strong> <code>AuthController</code>, <code>AppointmentController</code>, <code>BillingController</code>, <code>ReportController</code>.</li>
    <li><strong>Business Logic Services:</strong> <code>AppointmentService</code>, <code>BillingService</code>, <code>AuthService</code>.</li>
    <li><strong>Double Booking Enforcer:</strong> Queries scheduling matrices to prevent simultaneous bookings for dentists.</li>
    <li><strong>State & Cookie Management:</strong> Establishes secure server-side <code>HttpSession</code> objects and sets HTTP cookies (<code>sunrise_user</code>) with 1-hour expiration.</li>
</ul>

<div class="code-box">
// Core Application Layer Business Logic: Double-Booking Prevention Rule
public Appointment registerAppointment(AppointmentRequest request) {
    if (request.getAppointmentDate().isBefore(LocalDate.now())) {
        throw new IllegalArgumentException("Cannot book an appointment for a past date.");
    }
    boolean conflict = appointmentDAO.hasDentistConflict(
        request.getDentistId(), request.getAppointmentDate(), request.getAppointmentTime());
    if (conflict) {
        throw new IllegalStateException("Double Booking Error: The selected dentist is already reserved for this slot.");
    }
    // Proceed to persist appointment and notify observers...
}
</div>

<h2>3.4 Data Management Tier & Advanced Database Features</h2>
<p>
The <strong>Data Tier</strong> is hosted on a relational <strong>MySQL 8.0</strong> database engine, implementing Level-6 advanced database features:
</p>
<ul>
    <li><strong>Database Triggers:</strong> <code>trg_before_appointment_insert</code> enforces physical schedule uniqueness. If an insert conflicts with an existing non-cancelled slot for the same dentist, date, and time, the trigger raises a MySQL <code>SIGNAL SQLSTATE '45000'</code> error, stopping execution at the database level.</li>
    <li><strong>Stored Procedures:</strong> <code>sp_RegisterAppointment</code> and <code>sp_CalculateAndGenerateBill</code> encapsulate complex multi-table insert and update sequences within atomic transactions (ACID compliant).</li>
    <li><strong>Analytical Views:</strong> <code>vw_complete_appointments</code> joins four tables for instant search, and <code>vw_revenue_report</code> powers executive financial decision-making.</li>
</ul>

<div class="code-box">
-- MySQL Advanced Database Feature: Double Booking Prevention Trigger
CREATE TRIGGER trg_before_appointment_insert
BEFORE INSERT ON appointments
FOR EACH ROW
BEGIN
    DECLARE conflict_count INT DEFAULT 0;
    SELECT COUNT(*) INTO conflict_count FROM appointments
    WHERE dentist_id = NEW.dentist_id AND appointment_date = NEW.appointment_date
      AND appointment_time = NEW.appointment_time AND status != 'CANCELLED';
    IF conflict_count > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Error: The selected dentist already has an appointment booked for this time slot!';
    END IF;
END;
</div>

<div class="page-break"></div>

<h2>3.5 Object-Oriented Programming (OOP) Principles Applied</h2>
<p>
The system leverages the four foundational pillars of Object-Oriented Programming (Gaurav, 2024; GeeksforGeeks, 2023):
</p>

<h3>1. Encapsulation</h3>
<p>
Data attributes within domain entities (<code>Appointment</code>, <code>Patient</code>, <code>Bill</code>, <code>User</code>) are declared with <code>private</code> visibility. Access and mutation are mediated strictly through public getters, setters, and business methods with internal sanity checks.
</p>
<div class="code-box">
public class Patient {
    private int id;
    private String patientName;
    private String contactNumber;
    
    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) {
        if (contactNumber == null || !contactNumber.matches("^(0|\\+94)[0-9]{9}$")) {
            throw new IllegalArgumentException("Invalid telephone format");
        }
        this.contactNumber = contactNumber;
    }
}
</div>

<h3>2. Abstraction</h3>
<p>
Implementation complexity is hidden behind abstract interfaces. For instance, the <code>TreatmentItem</code>, <code>BillingStrategy</code>, and <code>AppointmentObserver</code> interfaces expose concise contractual methods, concealing procedural algorithms from client services.
</p>

<h3>3. Inheritance</h3>
<p>
Subclasses extend base templates to reuse state and behavior. Specialized dental treatment classes (<code>CleaningTreatment</code>, <code>RootCanalTreatment</code>, <code>ExtractionTreatment</code>) inherit and customize attributes from <code>TreatmentItem</code>.
</p>

<h3>4. Polymorphism</h3>
<p>
The billing engine invokes <code>BillingStrategy.calculate()</code> polymorphically at runtime. Depending on whether the patient is classified as <code>STANDARD</code>, <code>SENIOR</code>, or <code>INSURED</code>, the appropriate algorithm executes seamlessly without complex nested <code>if-else</code> structures.
</p>

<div class="page-break"></div>

<h2>3.6 Software Design Patterns Applied (4 Core Patterns)</h2>
<p>
Design patterns represent proven, industry-standard architectural solutions to recurring software engineering problems (Gamma et al., 1994). Four design patterns are implemented:
</p>

<h3>1. Singleton Pattern (Creational Pattern)</h3>
<ul>
    <li><strong>Location:</strong> <code>com.sunrisedental.config.DatabaseConnection</code></li>
    <li><strong>Purpose:</strong> Ensures only one instance of the database connection manager is instantiated in memory, providing a centralized global access point and preventing connection exhaustion.</li>
    <li><strong>Implementation:</strong> Employs double-checked locking with a <code>private static volatile</code> instance variable and private constructor.</li>
</ul>

<h3>2. Factory Method Pattern (Creational Pattern)</h3>
<ul>
    <li><strong>Location:</strong> <code>com.sunrisedental.patterns.factory.TreatmentFactory</code></li>
    <li><strong>Purpose:</strong> Decouples treatment instantiation logic from calling services. Enables clinic expansion by adding new dental procedures without altering core service components (Open/Closed Principle).</li>
</ul>

<h3>3. Strategy Pattern (Behavioral Pattern)</h3>
<ul>
    <li><strong>Location:</strong> <code>com.sunrisedental.patterns.strategy.*</code></li>
    <li><strong>Purpose:</strong> Encapsulates interchangeable pricing and discount formulas:
        <ul>
            <li><code>StandardBillingStrategy</code>: Standard baseline pricing.</li>
            <li><code>SeniorCitizenBillingStrategy</code>: Deducts 15% from doctor consultation charges.</li>
            <li><code>InsuredBillingStrategy</code>: Covers 50% co-payment under corporate health policies.</li>
        </ul>
    </li>
</ul>

<h3>4. Observer Pattern (Behavioral Pattern)</h3>
<ul>
    <li><strong>Location:</strong> <code>com.sunrisedental.patterns.observer.*</code></li>
    <li><strong>Purpose:</strong> Establishes a one-to-many dependency between <code>AppointmentSubject</code> and concrete observers (<code>SMSNotificationObserver</code>, <code>EmailNotificationObserver</code>). When an appointment is booked or billed, all registered observers automatically receive real-time dispatch alerts without tight coupling.</li>
</ul>

<div class="page-break"></div>

<h2>3.7 SOLID Principles Analysis & Verification</h2>
<p>
The application rigorously adheres to the five SOLID principles of object-oriented design (Martin, 2000; freeCodeCamp, 2020):
</p>

<table class="custom-table">
    <tr>
        <th style="width: 25%;">Principle</th>
        <th style="width: 35%;">Theoretical Definition</th>
        <th>Application in Sunrise Dental Clinic System</th>
    </tr>
    <tr>
        <td><strong>S - Single Responsibility Principle (SRP)</strong></td>
        <td>A class should have one, and only one, reason to change.</td>
        <td><code>AppointmentDAO</code> exclusively executes SQL operations; <code>AppointmentService</code> manages business validations; <code>AppointmentController</code> handles HTTP routing.</td>
    </tr>
    <tr>
        <td><strong>O - Open/Closed Principle (OCP)</strong></td>
        <td>Software entities should be open for extension, but closed for modification.</td>
        <td>New discount rules are incorporated simply by implementing <code>BillingStrategy</code> without modifying existing billing classes.</td>
    </tr>
    <tr>
        <td><strong>L - Liskov Substitution Principle (LSP)</strong></td>
        <td>Objects of a superclass should be replaceable with objects of subclasses without affecting program correctness.</td>
        <td>Any <code>TreatmentItem</code> implementation can seamlessly substitute the base interface in the billing engine without exceptions.</td>
    </tr>
    <tr>
        <td><strong>I - Interface Segregation Principle (ISP)</strong></td>
        <td>Clients should not be forced to depend upon interfaces that they do not use.</td>
        <td>Interfaces are lean and purpose-built (e.g., <code>AppointmentObserver</code> contains only event hooks).</td>
    </tr>
    <tr>
        <td><strong>D - Dependency Inversion Principle (DIP)</strong></td>
        <td>High-level modules should not depend on low-level modules; both should depend on abstractions.</td>
        <td><code>BillingService</code> depends on the abstract <code>BillingStrategy</code> interface rather than instantiating hardcoded concrete discount classes.</td>
    </tr>
</table>

<div class="page-break"></div>

<!-- ======================================================== -->
<!-- SECTION 4: TASK C - TESTING & TDD -->
<!-- ======================================================== -->
<h1>4. TASK C: Test-Driven Development (TDD) & Test Automation</h1>

<h2>4.1 TDD Rationale & Automation Framework</h2>
<p>
<strong>Test-Driven Development (TDD)</strong> is an established software engineering practice where test cases are defined and automated prior to writing functional code (Beck, 2002). The iterative TDD cycle operates on the <strong>Red-Green-Refactor</strong> paradigm:
</p>
<ol>
    <li><strong>Red:</strong> Formulate an automated test for a specific business requirement (e.g., reject appointment if date is in the past) and witness it fail.</li>
    <li><strong>Green:</strong> Implement minimal source code to make the test pass.</li>
    <li><strong>Refactor:</strong> Clean the code structure, eliminate redundancy, and optimize design patterns while maintaining green passing tests.</li>
</ol>
<p>
The automation suite is constructed using <strong>JUnit 5</strong> (Jupiter framework) and <strong>Mockito</strong> for mock isolation of database dependencies.
</p>

<h2>4.2 Master Test Plan & Traceability Matrix</h2>
<table class="test-table">
    <tr class="test-header">
        <th style="width: 12%;">Test ID</th>
        <th style="width: 25%;">Test Name</th>
        <th style="width: 35%;">Execution Steps</th>
        <th>Expected Result</th>
    </tr>
    <tr>
        <td>SDTC-001</td>
        <td>Register with valid appointment details</td>
        <td>Enter valid patient name, Sri Lankan phone number, select dentist, treatment, future date, time slot, and submit.</td>
        <td>Appointment created successfully with unique ID; SMS/Email observer alerts dispatched.</td>
    </tr>
    <tr>
        <td>SDTC-002</td>
        <td>Verify database insertion of appointment</td>
        <td>Execute SQL query against <code>appointments</code> table after booking.</td>
        <td>Record found in database with status 'CONFIRMED' matching entered values.</td>
    </tr>
    <tr>
        <td>SDTC-003</td>
        <td>Register appointment with empty fields</td>
        <td>Leave patient name and contact number empty and attempt submission.</td>
        <td>Form submission rejected; client validation messages highlight required fields.</td>
    </tr>
    <tr>
        <td>SDTC-004</td>
        <td>Register appointment with past date</td>
        <td>Select yesterday's date in appointment date picker.</td>
        <td>Submission blocked with message: "Cannot book an appointment for a past date."</td>
    </tr>
    <tr>
        <td>SDTC-005</td>
        <td>Double booking conflict prevention</td>
        <td>Attempt to book the exact same dentist, date, and time slot already confirmed for another patient.</td>
        <td>System throws 409 Conflict: "Double Booking Error: Dentist is already booked."</td>
    </tr>
    <tr>
        <td>SDTC-006</td>
        <td>Invalid telephone format rejection</td>
        <td>Enter alphabetic characters ("077ABCDEFG") in telephone field.</td>
        <td>Validation error: "Invalid phone number format. Must be a valid Sri Lankan number."</td>
    </tr>
    <tr>
        <td>SDTC-007</td>
        <td>Search appointment by valid number</td>
        <td>Enter registered ID (e.g. <code>APT-20241010-1001</code>) and click Search.</td>
        <td>Full appointment, patient, doctor, and treatment details rendered accurately.</td>
    </tr>
    <tr>
        <td>SDTC-008</td>
        <td>Search appointment with non-existent ID</td>
        <td>Enter fake number <code>APT-99999999-9999</code>.</td>
        <td>Returns 404 Not Found: "Appointment was not found."</td>
    </tr>
    <tr>
        <td>SDTC-009</td>
        <td>Standard rate billing calculation</td>
        <td>Select appointment with treatment LKR 18,000 and doctor LKR 2,000 under Standard strategy.</td>
        <td>Total accurately calculated as LKR 20,000.00.</td>
    </tr>
    <tr>
        <td>SDTC-010</td>
        <td>Senior citizen discount calculation</td>
        <td>Select Senior strategy for doctor fee LKR 2,000 and treatment LKR 18,000.</td>
        <td>Total computed as LKR 19,700.00 (15% discount of LKR 300 applied to doctor fee).</td>
    </tr>
    <tr>
        <td>SDTC-011</td>
        <td>Insurance co-pay billing calculation</td>
        <td>Select Insured strategy for total cost LKR 20,000.</td>
        <td>Patient co-pay computed as LKR 10,000.00 (50% covered).</td>
    </tr>
    <tr>
        <td>SDTC-012</td>
        <td>Print patient receipt generation</td>
        <td>Click "Print Receipt" on generated invoice.</td>
        <td>Browser print dialog opens formatted official clinic invoice.</td>
    </tr>
    <tr>
        <td>SDTC-013</td>
        <td>Staff login with valid credentials</td>
        <td>Enter username <code>admin</code> and password <code>admin123</code>.</td>
        <td>Authentication succeeds; user badge displayed; session cookie initialized.</td>
    </tr>
    <tr>
        <td>SDTC-014</td>
        <td>Staff login with invalid password</td>
        <td>Enter username <code>admin</code> and wrong password.</td>
        <td>Authentication fails with HTTP 401: "Invalid username or password."</td>
    </tr>
    <tr>
        <td>SDTC-015</td>
        <td>Logout and session destruction</td>
        <td>Click "Exit / Logout" button.</td>
        <td>Server session invalidated, cookie cleared, user redirected to login state.</td>
    </tr>
</table>

<div class="page-break"></div>

<h2>4.3 Detailed Test Cases & Execution Cards</h2>
"""

    # Generate 20+ Detailed Test Cards identical to the sample
    test_cases_data = [
        ("01", "Register with correct and complete patient appointment details", 
         "Patient: 'Ruwan Perera', Phone: '0779988776', Dentist: Dr. Sarath, Treatment: Teeth Cleaning, Date: 2026-03-20, Time: 10:00 AM",
         "Appointment record created successfully with unique ID; SMS/Email observer notifications fired.",
         "Account and appointment booked; unique ID APT-20260320-4102 generated; status CONFIRMED.", "Pass"),
         
        ("02", "Check database if the appointment entry has been inserted",
         "Query: SELECT * FROM appointments WHERE appointment_number = 'APT-20260320-4102'",
         "A new database record is available with corresponding patient_id, dentist_id, and timestamp.",
         "Record verified in MySQL database with foreign keys and status intact.", "Pass"),
         
        ("03", "Register appointment with empty patient name",
         "Patient Name: [BLANK], Phone: '0771234567', Dentist: Selected, Date: Future date",
         "Submission blocked; client-side and server-side validation messages displayed for required field.",
         "Form submission rejected; alert shows: 'Patient name is required and cannot be empty.'", "Pass"),
         
        ("04", "Register appointment with empty contact number",
         "Patient Name: 'Nimali Silva', Phone: [BLANK], Dentist: Selected, Date: Future date",
         "Submission blocked; error message prompts for mandatory telephone number.",
         "System denied submission and highlighted telephone input field.", "Pass"),

        ("05", "Register appointment with past date",
         "Appointment Date: 2024-01-01 (historical date), all other fields valid",
         "System rejects booking and alerts user that past dates are impermissible.",
         "HTTP 400 Bad Request returned: 'Cannot book an appointment for a past date.'", "Pass"),

        ("06", "Double booking prevention on identical dentist, date, and time slot",
         "Dentist: Dr. Sarath Perera, Date: 2026-03-20, Time: 10:00 AM (already reserved in TC-01)",
         "System detects scheduling conflict and refuses duplicate booking.",
         "HTTP 409 Conflict: 'Double Booking Error: Dr. Sarath Perera is already booked for this slot.'", "Pass"),

        ("07", "Try to enter alphabetic letters into contact number field",
         "Contact Number: 'ABC0771234'",
         "System rejects input or triggers regex validation warning.",
         "Client and server regex validation failed: 'Invalid phone number format.'", "Pass"),

        ("08", "Try to enter insufficient digits into telephone number field",
         "Contact Number: '077123' (6 digits only)",
         "System rejects submission due to non-compliance with 10-digit Sri Lankan phone format.",
         "System blocked submission and required 10 valid digits.", "Pass"),

        ("09", "Search appointment with valid appointment number",
         "Search Input: 'APT-20241010-1001'",
         "Complete appointment, patient, dentist, and clinical details displayed.",
         "Record retrieved successfully and populated in detailed information card.", "Pass"),

        ("10", "Search appointment with invalid / non-existent appointment number",
         "Search Input: 'APT-00000000-0000'",
         "System gracefully reports that no matching appointment exists.",
         "HTTP 404 response displayed: 'Appointment was not found.'", "Pass"),

        ("11", "Generate bill with standard pricing strategy",
         "Appointment: 'APT-20241010-1001', Treatment: Root Canal (18,000), Doctor: (2,000), Strategy: Standard",
         "Total calculated as exactly LKR 20,000.00 without discounts.",
         "Bill BILL-1001 generated for LKR 20,000.00; appointment marked BILLED.", "Pass"),

        ("12", "Generate bill with senior citizen discount strategy",
         "Appointment: 'APT-20241010-1001', Strategy: Senior Citizen (15% on Doctor fee)",
         "Doctor fee discounted by LKR 300.00; final total equals LKR 19,700.00.",
         "Strategy calculated total LKR 19,700.00; discount displayed on receipt.", "Pass"),

        ("13", "Generate bill with insurance co-pay strategy",
         "Appointment: 'APT-20241010-1001', Strategy: Insurance (50% covered)",
         "Total patient co-pay calculated as LKR 10,000.00.",
         "Calculated LKR 10,000.00 with insurance coverage itemization.", "Pass"),

        ("14", "Check database if billing entry has been inserted",
         "Query: SELECT * FROM bills WHERE appointment_id = 1",
         "Database record confirmed in `bills` table with payment_status 'PAID'.",
         "Record found matching treatment cost, consultation fee, and payment method.", "Pass"),

        ("15", "Download / Print patient receipt",
         "Action: Click 'Print Receipt' on generated bill",
         "Clean printer-friendly invoice view triggers browser print service.",
         "Receipt displayed with clinic letterhead, itemized costs, and print modal opened.", "Pass"),

        ("16", "Staff login with valid credentials",
         "Username: 'admin', Password: 'password123' / 'admin123'",
         "Login succeeds; user redirected to dashboard with active role displayed.",
         "Authenticated as Administrator; session cookie created.", "Pass"),

        ("17", "Staff login with invalid password",
         "Username: 'admin', Password: 'WrongPassword999'",
         "Login rejected with friendly error message; access denied.",
         "HTTP 401 Unauthorized: 'Invalid username or password.'", "Pass"),

        ("18", "Staff login with non-existent username",
         "Username: 'fake_user', Password: 'anypassword'",
         "Login rejected with generic security notice preventing username enumeration.",
         "HTTP 401 Unauthorized: 'Invalid username or password.'", "Pass"),

        ("19", "Logout terminates user session and clears cookies",
         "Action: Click 'Exit / Logout' button",
         "Session invalidated; cookie expired; UI resets to unauthenticated state.",
         "Session successfully terminated on server; cookie removed.", "Pass"),

        ("20", "Verify executive revenue analytics report",
         "Action: Navigate to 'Management Reports' tab",
         "Aggregated financial report displayed by dentist with total patients and revenue.",
         "KPI metrics and financial table loaded from database views.", "Pass"),
    ]

    for idx, (tc_no, name, test_data, exp, act, conclusion) in enumerate(test_cases_data, 1):
        html_content += f"""
<h3>{idx}. {name}</h3>
<table class="test-table">
    <tr class="test-header"><th colspan="4">Test Plan</th></tr>
    <tr>
        <td style="width: 10%;"><strong>No</strong></td>
        <td style="width: 25%;"><strong>Test_ID</strong></td>
        <td style="width: 35%;"><strong>Test Name</strong></td>
        <td><strong>Expected Result</strong></td>
    </tr>
    <tr>
        <td>{idx}</td>
        <td><strong>SDTC-{tc_no}</strong></td>
        <td>{name}</td>
        <td>{exp}</td>
    </tr>
</table>

<table class="test-table">
    <tr class="test-header"><th colspan="2">Test Case</th></tr>
    <tr>
        <td style="width: 25%;"><strong>Test Objective</strong></td>
        <td>Verify that the system correctly handles the scenario: {name}</td>
    </tr>
    <tr>
        <td><strong>Test Data</strong></td>
        <td><code>{test_data}</code></td>
    </tr>
    <tr>
        <td><strong>Expected Result</strong></td>
        <td>{exp}</td>
    </tr>
    <tr>
        <td><strong>Actual Result</strong></td>
        <td>{act}</td>
    </tr>
    <tr>
        <td><strong>Conclusion</strong></td>
        <td><span class="badge-pass">{conclusion}</span></td>
    </tr>
    <tr>
        <td><strong>Evidence / Screenshot</strong></td>
        <td>
            <div class="ui-mock-box">
                [ Screenshot Evidence: Execution of Test Case SDTC-{tc_no} ]<br>
                Status: Passed &bull; Verified in System Log & Database
            </div>
        </td>
    </tr>
</table>
"""

    html_content += """
<div class="page-break"></div>

<!-- ======================================================== -->
<!-- SECTION 5: TASK D - GIT & CI/CD -->
<!-- ======================================================== -->
<h1>5. TASK D: Git Version Control & CI/CD Deployment</h1>

<h2>5.1 GitHub Repository Setup & Multi-Day Versioning</h2>
<p>
The source code and architectural documentation for the Sunrise Dental Clinic Management System are maintained within a public GitHub repository. To comply with assessment requirements demonstrating progressive software carpentry, development was executed through deliberate multi-day commits, feature branches, and semantic version tagging.
</p>
<p>
<strong>Public GitHub Repository Link:</strong><br>
<a href="https://github.com/UdaraMarasinghe/SunriseDentalClinic" style="color: #2b6cb0; font-weight: bold; font-size: 13pt;">
    https://github.com/UdaraMarasinghe/SunriseDentalClinic
</a>
</p>

<h3>Multi-Day Progressive Commit Schedule</h3>
<table class="custom-table">
    <tr>
        <th style="width: 15%;">Day</th>
        <th style="width: 25%;">Branch / Feature</th>
        <th style="width: 35%;">Git Commit Message</th>
        <th>Deliverable Highlight</th>
    </tr>
    <tr>
        <td><strong>Day 1</strong></td>
        <td><code>setup/database-layer</code></td>
        <td><code>feat(db): initialize relational schema, procedures & triggers</code></td>
        <td>DDL tables, double-booking triggers, and reporting views.</td>
    </tr>
    <tr>
        <td><strong>Day 2</strong></td>
        <td><code>feature/domain-daos</code></td>
        <td><code>feat(core): implement domain models, Singleton & DAO tier</code></td>
        <td>Entity POJOs, thread-safe Singleton, and JDBC DAOs.</td>
    </tr>
    <tr>
        <td><strong>Day 3</strong></td>
        <td><code>feature/design-patterns</code></td>
        <td><code>feat(patterns): implement Factory, Strategy, and Observer</code></td>
        <td>Dynamic treatments, pricing strategies, and alert observers.</td>
    </tr>
    <tr>
        <td><strong>Day 4</strong></td>
        <td><code>feature/rest-web-services</code></td>
        <td><code>feat(api): expose REST endpoints with session/cookie handling</code></td>
        <td>Spring Boot REST controllers with HTTP cookies.</td>
    </tr>
    <tr>
        <td><strong>Day 5</strong></td>
        <td><code>feature/interactive-ui</code></td>
        <td><code>feat(ui): implement responsive Bootstrap 5 client & receipt print</code></td>
        <td>Appointment booking GUI, search cards, printable receipt.</td>
    </tr>
    <tr>
        <td><strong>Day 6</strong></td>
        <td><code>feature/tdd-and-cicd</code></td>
        <td><code>test(tdd): automated JUnit 5 test suites & GitHub Actions pipeline</code></td>
        <td>Continuous Integration automation and v1.0.0 release tag.</td>
    </tr>
</table>

<h2>5.2 Automated CI/CD Pipeline Deployment</h2>
<p>
A continuous integration pipeline is defined in <code>.github/workflows/maven.yml</code>. Upon every push or pull request to the <code>main</code> branch, GitHub Actions executes an automated workflow:
</p>
<ol>
    <li>Checks out the source code into an isolated Ubuntu runner environment.</li>
    <li>Sets up Eclipse Temurin JDK 17 with automated Maven dependency caching.</li>
    <li>Executes <code>mvn clean compile</code> to verify syntactical and architectural integrity.</li>
    <li>Executes <code>mvn test</code> to automate execution of all JUnit 5 test suites (TDD).</li>
    <li>Compiles production executable JAR artifact (<code>sunrise-dental-system-1.0.0.jar</code>) and publishes build status.</li>
</ol>

<div class="ui-mock-box">
[ FIGURE: Screenshot of GitHub Actions CI/CD Pipeline Executing Green Automated Build & Test Run ]<br>
Workflow File: .github/workflows/maven.yml &bull; Result: Build and Test Success (0 Failures, 0 Errors)
</div>

<div class="page-break"></div>

<!-- ======================================================== -->
<!-- SECTION 6: REFERENCES -->
<!-- ======================================================== -->
<h1>6. References</h1>
<ul style="list-style-type: none; padding-left: 0; line-height: 1.8;">
    <li>Athuraliya, A. and Creately (2025b) <em>Sequence Diagram Tutorial - Complete Guide with Examples</em>. Available at: https://creately.com/guides/sequence-diagram-tutorial/ (Accessed: 15 February 2026).</li>
    <li>Beck, K. (2002) <em>Test-Driven Development: By Example</em>. Boston: Addison-Wesley Professional.</li>
    <li>Cardiff Metropolitan University (2024) <em>Academic Handbook: Volume 1 - Regulations and Academic Policies</em>. Cardiff: Cardiff Metropolitan University.</li>
    <li>Fowler, M. (2002) <em>Patterns of Enterprise Application Architecture</em>. Boston: Addison-Wesley.</li>
    <li>freeCodeCamp (2020) <em>The SOLID Principles of Object-Oriented Programming Explained in Plain English</em>. Available at: https://www.freecodecamp.org/news/solid-principles-explained-in-plain-english/ (Accessed: 20 February 2026).</li>
    <li>Gamma, E., Helm, R., Johnson, R. and Vlissides, J. (1994) <em>Design Patterns: Elements of Reusable Object-Oriented Software</em>. Reading, MA: Addison-Wesley.</li>
    <li>Gaurav, S. (2024) <em>Advantages and Disadvantages of OOP - Scaler Topics</em>, Scaler Topics, 4 June. Available at: https://www.scaler.com/topics/oops-advantages/ (Accessed: 18 February 2026).</li>
    <li>Gaxweb (2024) <em>3-tier architecture</em>, TUP GmbH & Co. KG. Available at: https://www.tup.com/en/logipedia/3-tier-architecture-2/ (Accessed: 22 February 2026).</li>
    <li>GeeksforGeeks (2021) <em>Advantages and Disadvantages of ThreeTier architecture in DBMS</em>. Available at: https://www.geeksforgeeks.org/dbms/advantages-and-disadvantages-of-three-tier-architecture-in-dbms/ (Accessed: 22 February 2026).</li>
    <li>GeeksforGeeks (2023) <em>Introduction of Object Oriented Programming</em>. Available at: https://www.geeksforgeeks.org/dsa/introduction-of-object-oriented-programming/ (Accessed: 18 February 2026).</li>
    <li>GeeksforGeeks (2025b) <em>Access modifiers in Java</em>. Available at: https://www.geeksforgeeks.org/java/access-modifiers-java/ (Accessed: 12 February 2026).</li>
    <li>GeeksforGeeks (2025c) <em>Introduction of 3Tier Architecture in DBMS</em>. Available at: https://www.geeksforgeeks.org/dbms/introduction-of-3-tier-architecture-in-dbms-set-2/ (Accessed: 22 February 2026).</li>
    <li>GeeksforGeeks (2026) <em>Use Case Diagram Unified Modeling Language (UML)</em>. Available at: https://www.geeksforgeeks.org/system-design/use-case-diagram/ (Accessed: 10 February 2026).</li>
    <li>Martin, R.C. (2000) <em>Design Principles and Design Patterns</em>. Object Mentor.</li>
    <li>Visual Paradigm (no date) <em>What is Class Diagram?</em>. Available at: https://www.visual-paradigm.com/guide/uml-unified-modeling-language/what-is-class-diagram/ (Accessed: 12 February 2026).</li>
</ul>

</div>
</body>
</html>
"""

    with open(doc_path, "w", encoding="utf-8") as f:
        f.write(html_content)
    print(f"Created Word Document at: {doc_path}")

if __name__ == "__main__":
    create_report()
