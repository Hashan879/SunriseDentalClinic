# Sunrise Dental Clinic Management System

**Course:** CIS6003 Advanced Programming  
**Institution:** Cardiff Metropolitan University (ICBT Campus)  
**Academic Year:** 2024 - Semester 1  

---

## 1. Project Overview
Sunrise Dental Clinic Management System is a **distributed enterprise application** designed to resolve operational inefficiencies associated with manual appointment booking, double bookings, lost records, and billing calculation errors.

### Key Architectural Highlights
- **3-Tier Distributed Architecture:** Clean separation of Presentation, Business Logic, and Data Access Layers.
- **RESTful Web Services:** Endpoints exposing patient management, booking, search, and invoicing.
- **Design Patterns Implemented:**
  - **Singleton Pattern:** Thread-safe Database Connection management (`DatabaseConnection.java`).
  - **Factory Method Pattern:** Dynamic dental treatment generation (`TreatmentFactory.java`).
  - **Strategy Pattern:** Flexible pricing and discount calculations (Standard, Senior Citizen, Insurance Co-Pay).
  - **Observer Pattern:** Real-time SMS and Email alert dispatches upon booking/billing events.
  - **Data Access Object (DAO) Pattern:** Decoupling SQL interactions from domain business logic.
- **Advanced MySQL Features:** Stored procedures (`sp_RegisterAppointment`, `sp_CalculateAndGenerateBill`), conflict prevention triggers, and analytical views.
- **Automated Testing:** Test-Driven Development (TDD) with JUnit 5 and Mockito.
- **CI/CD Automation:** GitHub Actions workflow executing build, unit testing, and artifact deployment.

---

## 2. Directory Structure

```text
SunriseDentalClinic/
├── database/
│   ├── 01_schema.sql                  # DDL tables & constraints
│   ├── 02_procedures_and_triggers.sql # Stored procedures, triggers, views
│   └── 03_seed_data.sql               # Seed data for staff, dentists, treatments
├── src/
│   ├── main/
│   │   ├── java/com/sunrisedental/
│   │   │   ├── config/                # Singleton Database Connection
│   │   │   ├── controller/            # Distributed REST Web Services
│   │   │   ├── dao/                   # Data Access Object Layer
│   │   │   ├── model/                 # Domain Entities & DTOs
│   │   │   ├── patterns/
│   │   │   │   ├── factory/           # Factory Method Pattern
│   │   │   │   ├── observer/          # Observer Pattern (SMS/Email)
│   │   │   │   └── strategy/          # Strategy Pattern (Billing Discounts)
│   │   │   ├── service/               # Core Business Logic & Validations
│   │   │   └── SunriseDentalApplication.java
│   │   └── resources/
│   │       ├── application.properties
│   │       └── static/                # Interactive Presentation Tier (HTML5/CSS/JS)
│   └── test/java/com/sunrisedental/   # Automated Unit Test Suites
├── .github/workflows/maven.yml        # CI/CD Automated Workflow
├── GIT_WORKFLOW_GUIDE.md              # Git Version Control Commands
└── pom.xml                            # Maven Dependencies & Build Configuration
```

---

## 3. How to Run the Application

### Prerequisites
- Java JDK 17 or higher
- Apache Maven 3.8+
- MySQL Server 8.0+

### Database Setup
1. Open your MySQL client (MySQL Workbench, phpMyAdmin, or terminal CLI).
2. Execute the scripts in the following sequence:
   ```sql
   source database/01_schema.sql;
   source database/02_procedures_and_triggers.sql;
   source database/03_seed_data.sql;
   ```

### Running the Application
From the project root directory:
```bash
# Compile and run unit tests
mvn clean test

# Start the Spring Boot Web Service application
mvn spring-boot:run
```

Once running:
- **Interactive Web Client:** Open `http://localhost:8080` in your web browser.
- **REST Web Services Base:** `http://localhost:8080/api`

---

## 4. Default Login Credentials
- **Administrator:** `admin` / `admin123` (Full system and reports access)
- **Receptionist:** `receptionist` / `recep123` (Appointment bookings & billing)
- **Dentist:** `dentist` / `doc123` (Clinical schedule view)
