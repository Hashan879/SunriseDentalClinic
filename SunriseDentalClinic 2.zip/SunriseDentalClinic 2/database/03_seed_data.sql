-- =======================================================
-- Database: sunrise_dental_db
-- Description: Seed Data for Sunrise Dental Clinic Management System
-- Module: CIS6003 Advanced Programming (Cardiff Metropolitan University)
-- =======================================================

USE sunrise_dental_db;

-- 1. Insert Staff Users
-- Passwords stored for demo (in production hashed with BCrypt):
-- admin / admin123, receptionist / recep123, dentist / doc123
INSERT INTO users (username, password_hash, full_name, role, email) VALUES
('admin', 'admin123', 'System Administrator', 'ADMIN', 'admin@sunrisedental.lk'),
('receptionist', 'recep123', 'Sunil Jayawardena', 'RECEPTIONIST', 'reception@sunrisedental.lk'),
('dentist', 'doc123', 'Dr. Sarath Perera', 'DENTIST', 'sarath@sunrisedental.lk');

-- 2. Insert Dentists
INSERT INTO dentists (name, specialization, consultation_fee, contact_number, email) VALUES
('Dr. Sarath Perera', 'Consultant Dental Surgeon', 2000.00, '+94771234567', 'sarath@sunrisedental.lk'),
('Dr. Nimalee Jayasuriya', 'Specialist Orthodontist', 2500.00, '+94772345678', 'nimalee@sunrisedental.lk'),
('Dr. Kasun Fernando', 'Endodontics & Restorative Specialist', 2200.00, '+94773456789', 'kasun@sunrisedental.lk'),
('Dr. Anusha Silva', 'Pediatric Dental Specialist', 1800.00, '+94774567890', 'anusha@sunrisedental.lk');

-- 3. Insert Treatment Catalog
INSERT INTO treatments (treatment_name, description, base_cost, estimated_duration_minutes) VALUES
('Teeth Cleaning & Scaling', 'Ultrasonic tartar removal and plaque polishing', 3000.00, 30),
('Composite Dental Filling', 'Tooth-coloured light cure resin filling', 4500.00, 45),
('Root Canal Treatment (RCT)', 'Endodontic multi-session nerve therapy', 18000.00, 60),
('Surgical Tooth Extraction', 'Painless wisdom or damaged tooth extraction', 5500.00, 45),
('Professional Laser Whitening', 'Cosmetic high-intensity teeth bleaching', 25000.00, 60),
('Porcelain Dental Crown', 'Custom fabricated high-durability tooth cap', 22000.00, 60);

-- 4. Insert Initial Patients
INSERT INTO patients (patient_name, address, contact_number, email) VALUES
('Kamal Gunaratne', 'No 45, Galle Road, Colombo 03', '0778899111', 'kamal.g@gmail.com'),
('Nimali Wickramasinghe', 'No 12/A, Havelock Road, Colombo 05', '0714455667', 'nimali.w@yahoo.com'),
('Rohan Senanayake', 'No 88, Kandy Road, Kiribathgoda', '0761122334', 'rohan.s@outlook.com');

-- 5. Insert Sample Appointments
INSERT INTO appointments (appointment_number, patient_id, dentist_id, treatment_id, appointment_date, appointment_time, status, notes) VALUES
('APT-20241010-1001', 1, 1, 1, '2024-10-10', '09:00:00', 'BILLED', 'Routine 6-month checkup'),
('APT-20241010-1002', 2, 2, 3, '2024-10-10', '10:30:00', 'CONFIRMED', 'Severe toothache in lower molar'),
('APT-20241011-1003', 3, 3, 2, '2024-10-11', '14:00:00', 'CONFIRMED', 'Front tooth cavity repair');

-- 6. Insert Sample Bill
INSERT INTO bills (bill_number, appointment_id, treatment_cost, consultation_fee, tax_amount, discount_amount, total_amount, payment_method, payment_status) VALUES
('BILL-1728550800-101', 1, 3000.00, 2000.00, 0.00, 0.00, 5000.00, 'CARD', 'PAID');
