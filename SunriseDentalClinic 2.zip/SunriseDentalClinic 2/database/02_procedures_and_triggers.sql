-- =======================================================
-- Database: sunrise_dental_db
-- Description: Stored Procedures, Functions, Triggers, and Analytical Views
-- Module: CIS6003 Advanced Programming (Cardiff Metropolitan University)
-- Criteria: Advanced Database Features (70-100% Rubric)
-- =======================================================

USE sunrise_dental_db;

DELIMITER //

-- -------------------------------------------------------
-- 1. TRIGGER: Prevent Double Booking at Database Level
-- Enforces business rule that a dentist cannot take two patients at the same time slot
-- -------------------------------------------------------
DROP TRIGGER IF EXISTS trg_before_appointment_insert //
CREATE TRIGGER trg_before_appointment_insert
BEFORE INSERT ON appointments
FOR EACH ROW
BEGIN
    DECLARE conflict_count INT DEFAULT 0;

    SELECT COUNT(*) INTO conflict_count
    FROM appointments
    WHERE dentist_id = NEW.dentist_id
      AND appointment_date = NEW.appointment_date
      AND appointment_time = NEW.appointment_time
      AND status != 'CANCELLED';

    IF conflict_count > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Error: The selected dentist already has an appointment booked for this time slot!';
    END IF;
END //

-- -------------------------------------------------------
-- 2. TRIGGER: Audit Trail Trigger on Appointment Creation
-- Automatically records every booked appointment into audit_logs table
-- -------------------------------------------------------
DROP TRIGGER IF EXISTS trg_after_appointment_insert //
CREATE TRIGGER trg_after_appointment_insert
AFTER INSERT ON appointments
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (action_type, entity_name, entity_id, details, created_by)
    VALUES (
        'APPOINTMENT_CREATED',
        'appointments',
        NEW.appointment_number,
        CONCAT('Booked appointment for Patient ID: ', NEW.patient_id, ', Dentist ID: ', NEW.dentist_id, ', Date: ', NEW.appointment_date, ' ', NEW.appointment_time),
        'SYSTEM_TRIGGER'
    );
END //

-- -------------------------------------------------------
-- 3. STORED PROCEDURE: Register New Appointment
-- Handles patient check/registration and books appointment transactionally
-- -------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_RegisterAppointment //
CREATE PROCEDURE sp_RegisterAppointment(
    IN p_patient_name VARCHAR(100),
    IN p_address TEXT,
    IN p_contact_number VARCHAR(20),
    IN p_email VARCHAR(100),
    IN p_dentist_id INT,
    IN p_treatment_id INT,
    IN p_appointment_date DATE,
    IN p_appointment_time TIME,
    IN p_notes TEXT,
    OUT p_appointment_number VARCHAR(30)
)
proc_label: BEGIN
    DECLARE v_patient_id INT;
    DECLARE v_new_number VARCHAR(30);

    -- Transaction boundary
    START TRANSACTION;

    -- Check if patient already exists by phone number; if not, create new patient record
    SELECT id INTO v_patient_id 
    FROM patients 
    WHERE contact_number = p_contact_number 
    LIMIT 1;

    IF v_patient_id IS NULL THEN
        INSERT INTO patients (patient_name, address, contact_number, email)
        VALUES (p_patient_name, p_address, p_contact_number, p_email);
        SET v_patient_id = LAST_INSERT_ID();
    ELSE
        -- Update contact details if needed
        UPDATE patients 
        SET address = p_address, patient_name = p_patient_name, email = p_email
        WHERE id = v_patient_id;
    END IF;

    -- Generate unique appointment number (Format: APT-YYYYMMDD-XXXX)
    SET v_new_number = CONCAT('APT-', DATE_FORMAT(p_appointment_date, '%Y%m%d'), '-', LPAD(FLOOR(RAND() * 9000) + 1000, 4, '0'));

    -- Insert appointment record (Trigger will check for double booking)
    INSERT INTO appointments (
        appointment_number, patient_id, dentist_id, treatment_id, 
        appointment_date, appointment_time, status, notes
    ) VALUES (
        v_new_number, v_patient_id, p_dentist_id, p_treatment_id, 
        p_appointment_date, p_appointment_time, 'CONFIRMED', p_notes
    );

    SET p_appointment_number = v_new_number;
    COMMIT;
END //

-- -------------------------------------------------------
-- 4. STORED PROCEDURE: Calculate and Generate Bill
-- Calculates cost based on treatment price + consultation fee and applies standard rates
-- -------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_CalculateAndGenerateBill //
CREATE PROCEDURE sp_CalculateAndGenerateBill(
    IN p_appointment_number VARCHAR(30),
    IN p_payment_method VARCHAR(20),
    OUT p_bill_number VARCHAR(30),
    OUT p_total_amount DECIMAL(10, 2)
)
BEGIN
    DECLARE v_appointment_id INT;
    DECLARE v_treatment_cost DECIMAL(10, 2);
    DECLARE v_consultation_fee DECIMAL(10, 2);
    DECLARE v_tax DECIMAL(10, 2) DEFAULT 0.00;
    DECLARE v_discount DECIMAL(10, 2) DEFAULT 0.00;
    DECLARE v_final_total DECIMAL(10, 2);
    DECLARE v_new_bill_number VARCHAR(30);

    START TRANSACTION;

    -- Fetch appointment details, treatment cost and dentist fee
    SELECT 
        a.id, t.base_cost, d.consultation_fee
    INTO 
        v_appointment_id, v_treatment_cost, v_consultation_fee
    FROM appointments a
    JOIN treatments t ON a.treatment_id = t.id
    JOIN dentists d ON a.dentist_id = d.id
    WHERE a.appointment_number = p_appointment_number;

    IF v_appointment_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Appointment not found.';
    END IF;

    -- Calculate totals
    SET v_final_total = v_treatment_cost + v_consultation_fee - v_discount + v_tax;
    SET v_new_bill_number = CONCAT('BILL-', UNIX_TIMESTAMP(), '-', LPAD(FLOOR(RAND() * 900) + 100, 3, '0'));

    -- Insert into bills table
    INSERT INTO bills (
        bill_number, appointment_id, treatment_cost, consultation_fee, 
        tax_amount, discount_amount, total_amount, payment_method, payment_status
    ) VALUES (
        v_new_bill_number, v_appointment_id, v_treatment_cost, v_consultation_fee,
        v_tax, v_discount, v_final_total, p_payment_method, 'PAID'
    );

    -- Update appointment status to BILLED
    UPDATE appointments SET status = 'BILLED' WHERE id = v_appointment_id;

    -- Log transaction
    INSERT INTO audit_logs (action_type, entity_name, entity_id, details, created_by)
    VALUES ('BILL_GENERATED', 'bills', v_new_bill_number, CONCAT('Amount: LKR ', v_final_total), 'SYSTEM');

    SET p_bill_number = v_new_bill_number;
    SET p_total_amount = v_final_total;

    COMMIT;
END //

DELIMITER ;

-- -------------------------------------------------------
-- 5. ANALYTICAL VIEWS (Decision Making Reports)
-- -------------------------------------------------------

-- View: Complete Appointment Details View
CREATE OR REPLACE VIEW vw_complete_appointments AS
SELECT 
    a.id AS appointment_id,
    a.appointment_number,
    p.patient_name,
    p.address AS patient_address,
    p.contact_number,
    p.email AS patient_email,
    d.id AS dentist_id,
    d.name AS dentist_name,
    d.specialization AS dentist_specialization,
    d.consultation_fee,
    t.id AS treatment_id,
    t.treatment_name,
    t.base_cost AS treatment_cost,
    a.appointment_date,
    a.appointment_time,
    a.status,
    a.notes,
    b.bill_number,
    b.total_amount,
    b.payment_status
FROM appointments a
JOIN patients p ON a.patient_id = p.id
JOIN dentists d ON a.dentist_id = d.id
JOIN treatments t ON a.treatment_id = t.id
LEFT JOIN bills b ON a.id = b.appointment_id;

-- View: Daily Appointments Summary
CREATE OR REPLACE VIEW vw_daily_summary AS
SELECT 
    appointment_date,
    COUNT(id) AS total_appointments,
    SUM(CASE WHEN status = 'CONFIRMED' THEN 1 ELSE 0 END) AS confirmed_count,
    SUM(CASE WHEN status = 'BILLED' THEN 1 ELSE 0 END) AS billed_count,
    SUM(CASE WHEN status = 'CANCELLED' THEN 1 ELSE 0 END) AS cancelled_count
FROM appointments
GROUP BY appointment_date
ORDER BY appointment_date DESC;

-- View: Revenue & Performance Report
CREATE OR REPLACE VIEW vw_revenue_report AS
SELECT 
    d.name AS dentist_name,
    COUNT(b.id) AS total_patients_treated,
    SUM(b.treatment_cost) AS total_treatment_revenue,
    SUM(b.consultation_fee) AS total_consultation_fees,
    SUM(b.total_amount) AS total_revenue
FROM bills b
JOIN appointments a ON b.appointment_id = a.id
JOIN dentists d ON a.dentist_id = d.id
GROUP BY d.id, d.name;
