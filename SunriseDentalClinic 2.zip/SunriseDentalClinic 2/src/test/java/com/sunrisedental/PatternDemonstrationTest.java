package com.sunrisedental;

import com.sunrisedental.config.DatabaseConnection;
import com.sunrisedental.patterns.factory.CleaningTreatment;
import com.sunrisedental.patterns.factory.RootCanalTreatment;
import com.sunrisedental.patterns.factory.TreatmentFactory;
import com.sunrisedental.patterns.factory.TreatmentItem;
import com.sunrisedental.patterns.observer.AppointmentObserver;
import com.sunrisedental.patterns.observer.AppointmentSubject;
import com.sunrisedental.patterns.observer.EmailNotificationObserver;
import com.sunrisedental.patterns.observer.SMSNotificationObserver;
import com.sunrisedental.patterns.strategy.BillingCalculationResult;
import com.sunrisedental.patterns.strategy.SeniorCitizenBillingStrategy;
import com.sunrisedental.patterns.strategy.StandardBillingStrategy;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Task B & C: Design Pattern Verification Tests
 * Verifies correctness of Singleton, Factory, Strategy, and Observer patterns
 */
public class PatternDemonstrationTest {

    @Test
    @DisplayName("Design Pattern 1: Singleton Pattern Verification")
    void testSingletonIntegrity() {
        DatabaseConnection instance1 = DatabaseConnection.getInstance();
        DatabaseConnection instance2 = DatabaseConnection.getInstance();

        assertNotNull(instance1);
        assertNotNull(instance2);
        // Verify both references point to the exact same instance in memory
        assertSame(instance1, instance2, "Singleton must return identical instance reference");
    }

    @Test
    @DisplayName("Design Pattern 2: Factory Method Pattern Verification")
    void testFactoryPatternCreation() {
        TreatmentItem cleaning = TreatmentFactory.createTreatment(1, null, 0);
        TreatmentItem rootCanal = TreatmentFactory.createTreatment(3, null, 0);

        assertTrue(cleaning instanceof CleaningTreatment);
        assertEquals(new BigDecimal("3000.00"), cleaning.getBaseCost());
        assertFalse(cleaning.requiresPreMedication());

        assertTrue(rootCanal instanceof RootCanalTreatment);
        assertEquals(new BigDecimal("18000.00"), rootCanal.getBaseCost());
        assertTrue(rootCanal.requiresPreMedication());
    }

    @Test
    @DisplayName("Design Pattern 3: Strategy Pattern Verification")
    void testStrategyPatternBehavior() {
        BigDecimal treatmentFee = new BigDecimal("10000.00");
        BigDecimal consultation = new BigDecimal("2000.00");

        StandardBillingStrategy standard = new StandardBillingStrategy();
        BillingCalculationResult stdResult = standard.calculate(treatmentFee, consultation);
        assertEquals(new BigDecimal("12000.00"), stdResult.getFinalTotal());

        SeniorCitizenBillingStrategy senior = new SeniorCitizenBillingStrategy();
        BillingCalculationResult seniorResult = senior.calculate(treatmentFee, consultation);
        // 10000 + (2000 - 300) = 11700.00
        assertEquals(new BigDecimal("11700.00"), seniorResult.getFinalTotal());
    }

    @Test
    @DisplayName("Design Pattern 4: Observer Pattern Event Dispatch")
    void testObserverPatternNotification() {
        SMSNotificationObserver sms = mock(SMSNotificationObserver.class);
        EmailNotificationObserver email = mock(EmailNotificationObserver.class);

        AppointmentSubject subject = new AppointmentSubject(sms, email);
        subject.notifyAppointmentBilled("APT-TEST-1", "BILL-TEST-1", 7500.0);

        verify(sms, times(1)).onAppointmentBilled("APT-TEST-1", "BILL-TEST-1", 7500.0);
        verify(email, times(1)).onAppointmentBilled("APT-TEST-1", "BILL-TEST-1", 7500.0);
    }
}
