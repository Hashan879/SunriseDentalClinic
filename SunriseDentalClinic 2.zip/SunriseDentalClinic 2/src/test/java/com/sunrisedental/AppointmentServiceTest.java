package com.sunrisedental;

import com.sunrisedental.dao.AppointmentDAO;
import com.sunrisedental.dao.DentistDAO;
import com.sunrisedental.dao.TreatmentDAO;
import com.sunrisedental.model.Appointment;
import com.sunrisedental.model.AppointmentRequest;
import com.sunrisedental.model.Dentist;
import com.sunrisedental.model.Treatment;
import com.sunrisedental.patterns.observer.AppointmentSubject;
import com.sunrisedental.service.AppointmentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Task C: Test-Driven Development (TDD) Automated Unit Tests
 * Unit tests for AppointmentService covering business rules and edge cases
 */
@ExtendWith(MockitoExtension.class)
public class AppointmentServiceTest {

    @Mock
    private AppointmentDAO appointmentDAO;

    @Mock
    private DentistDAO dentistDAO;

    @Mock
    private TreatmentDAO treatmentDAO;

    @Mock
    private AppointmentSubject appointmentSubject;

    @InjectMocks
    private AppointmentService appointmentService;

    private Dentist testDentist;
    private Treatment testTreatment;
    private AppointmentRequest validRequest;

    @BeforeEach
    void setUp() {
        testDentist = new Dentist(1, "Dr. Sarath Perera", "Consultant Dental Surgeon",
                new BigDecimal("2000.00"), "0771234567", "sarath@sunrisedental.lk");

        testTreatment = new Treatment(1, "Teeth Cleaning & Scaling",
                "Ultrasonic tartar removal", new BigDecimal("3000.00"), 30);

        validRequest = new AppointmentRequest();
        validRequest.setPatientName("Ruwan Perera");
        validRequest.setAddress("No 10, Kandy Road");
        validRequest.setContactNumber("0779988776");
        validRequest.setEmail("ruwan@gmail.com");
        validRequest.setDentistId(1);
        validRequest.setTreatmentId(1);
        validRequest.setAppointmentDate(LocalDate.now().plusDays(2));
        validRequest.setAppointmentTime(LocalTime.of(10, 0));
        validRequest.setNotes("Regular checkup");
    }

    @Test
    @DisplayName("TC-01: Successfully Register Appointment with Valid Data")
    void testRegisterAppointment_Success() {
        // Arrange
        when(dentistDAO.findById(1)).thenReturn(Optional.of(testDentist));
        when(treatmentDAO.findById(1)).thenReturn(Optional.of(testTreatment));
        when(appointmentDAO.hasDentistConflict(eq(1), any(LocalDate.class), any(LocalTime.class))).thenReturn(false);
        when(appointmentDAO.findOrCreatePatient(anyString(), anyString(), anyString(), anyString())).thenReturn(101);
        when(appointmentDAO.insertAppointment(eq(101), eq(1), eq(1), any(LocalDate.class), any(LocalTime.class), anyString()))
                .thenReturn("APT-20241020-5555");

        Appointment mockCreated = new Appointment();
        mockCreated.setAppointmentNumber("APT-20241020-5555");
        mockCreated.setPatientName("Ruwan Perera");
        mockCreated.setDentistName("Dr. Sarath Perera");
        when(appointmentDAO.findByAppointmentNumber("APT-20241020-5555")).thenReturn(Optional.of(mockCreated));

        // Act
        Appointment result = appointmentService.registerAppointment(validRequest);

        // Assert
        assertNotNull(result);
        assertEquals("APT-20241020-5555", result.getAppointmentNumber());
        assertEquals("Ruwan Perera", result.getPatientName());

        // Verify Observer pattern notification was fired
        verify(appointmentSubject, times(1)).notifyAppointmentBooked(any(Appointment.class));
    }

    @Test
    @DisplayName("TC-02: Double Booking Prevention - Rejects conflicting slot for same dentist")
    void testRegisterAppointment_DoubleBookingConflict() {
        // Arrange
        when(dentistDAO.findById(1)).thenReturn(Optional.of(testDentist));
        when(treatmentDAO.findById(1)).thenReturn(Optional.of(testTreatment));
        when(appointmentDAO.hasDentistConflict(eq(1), any(LocalDate.class), any(LocalTime.class))).thenReturn(true);

        // Act & Assert
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            appointmentService.registerAppointment(validRequest);
        });

        assertTrue(exception.getMessage().contains("Double Booking Error"));
        // Verify insert was never called
        verify(appointmentDAO, never()).insertAppointment(anyInt(), anyInt(), anyInt(), any(), any(), any());
    }

    @Test
    @DisplayName("TC-03: Past Date Validation - Rejects booking attempted for a past date")
    void testRegisterAppointment_PastDateRejection() {
        // Set date to yesterday
        validRequest.setAppointmentDate(LocalDate.now().minusDays(1));

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.registerAppointment(validRequest);
        });

        assertEquals("Cannot book an appointment for a past date.", exception.getMessage());
        verify(appointmentDAO, never()).hasDentistConflict(anyInt(), any(), any());
    }

    @Test
    @DisplayName("TC-04: Non-existent Dentist Validation")
    void testRegisterAppointment_DentistNotFound() {
        // Arrange
        when(dentistDAO.findById(1)).thenReturn(Optional.empty());

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.registerAppointment(validRequest);
        });

        assertTrue(exception.getMessage().contains("Selected dentist does not exist"));
    }
}
