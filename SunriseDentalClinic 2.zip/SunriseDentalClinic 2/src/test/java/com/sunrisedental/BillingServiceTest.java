package com.sunrisedental;

import com.sunrisedental.dao.AppointmentDAO;
import com.sunrisedental.dao.BillDAO;
import com.sunrisedental.model.Appointment;
import com.sunrisedental.model.Bill;
import com.sunrisedental.model.BillingRequest;
import com.sunrisedental.patterns.observer.AppointmentSubject;
import com.sunrisedental.service.BillingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Task C: Test-Driven Development (TDD) Automated Unit Tests
 * Unit tests for BillingService and Pricing Strategy Patterns
 */
@ExtendWith(MockitoExtension.class)
public class BillingServiceTest {

    @Mock
    private BillDAO billDAO;

    @Mock
    private AppointmentDAO appointmentDAO;

    @Mock
    private AppointmentSubject appointmentSubject;

    @InjectMocks
    private BillingService billingService;

    private Appointment sampleAppointment;

    @BeforeEach
    void setUp() {
        sampleAppointment = new Appointment();
        sampleAppointment.setId(10);
        sampleAppointment.setAppointmentNumber("APT-20241010-1001");
        sampleAppointment.setPatientName("Nimal Perera");
        sampleAppointment.setDentistName("Dr. Sarath Perera");
        sampleAppointment.setTreatmentName("Root Canal Treatment (RCT)");
        sampleAppointment.setTreatmentCost(18000.00);
        sampleAppointment.setConsultationFee(2000.00);
    }

    @Test
    @DisplayName("TC-05: Standard Rate Billing Calculation (Base Cost + Consultation Fee)")
    void testStandardBillingCalculation() {
        // Arrange
        BillingRequest request = new BillingRequest("APT-20241010-1001", "CASH", "STANDARD");
        when(appointmentDAO.findByAppointmentNumber("APT-20241010-1001")).thenReturn(Optional.of(sampleAppointment));
        when(billDAO.findByAppointmentNumber("APT-20241010-1001")).thenReturn(Optional.empty());

        Bill mockBill = new Bill();
        mockBill.setBillNumber("BILL-1001");
        mockBill.setTotalAmount(new BigDecimal("20000.00")); // 18,000 + 2,000
        when(billDAO.saveBill(eq(10), eq(new BigDecimal("18000.0")), eq(new BigDecimal("2000.0")),
                eq(BigDecimal.ZERO), eq(BigDecimal.ZERO), eq(new BigDecimal("20000.0")), eq("CASH")))
                .thenReturn(mockBill);

        // Act
        Bill result = billingService.generateBill(request);

        // Assert
        assertNotNull(result);
        assertEquals(new BigDecimal("20000.00"), result.getTotalAmount());
        verify(appointmentSubject, times(1)).notifyAppointmentBilled(eq("APT-20241010-1001"), anyString(), anyDouble());
    }

    @Test
    @DisplayName("TC-06: Senior Citizen Discount Billing (15% off Consultation Fee)")
    void testSeniorCitizenDiscountBilling() {
        // Arrange
        BillingRequest request = new BillingRequest("APT-20241010-1001", "CARD", "SENIOR");
        when(appointmentDAO.findByAppointmentNumber("APT-20241010-1001")).thenReturn(Optional.of(sampleAppointment));
        when(billDAO.findByAppointmentNumber("APT-20241010-1001")).thenReturn(Optional.empty());

        // 18,000 + 2,000 - 300 (15% of 2000) = 19,700.00
        Bill mockBill = new Bill();
        mockBill.setTotalAmount(new BigDecimal("19700.00"));

        when(billDAO.saveBill(eq(10), eq(new BigDecimal("18000.0")), eq(new BigDecimal("2000.0")),
                eq(new BigDecimal("300.00")), eq(BigDecimal.ZERO), eq(new BigDecimal("19700.00")), eq("CARD")))
                .thenReturn(mockBill);

        // Act
        Bill result = billingService.generateBill(request);

        // Assert
        assertNotNull(result);
        assertEquals(new BigDecimal("19700.00"), result.getTotalAmount());
    }

    @Test
    @DisplayName("TC-07: Insured Patient Billing (50% Co-Pay)")
    void testInsuredPatientBilling() {
        // Arrange
        BillingRequest request = new BillingRequest("APT-20241010-1001", "INSURANCE", "INSURED");
        when(appointmentDAO.findByAppointmentNumber("APT-20241010-1001")).thenReturn(Optional.of(sampleAppointment));
        when(billDAO.findByAppointmentNumber("APT-20241010-1001")).thenReturn(Optional.empty());

        // (18,000 + 2,000) * 0.50 = 10,000.00
        Bill mockBill = new Bill();
        mockBill.setTotalAmount(new BigDecimal("10000.00"));

        when(billDAO.saveBill(eq(10), eq(new BigDecimal("18000.0")), eq(new BigDecimal("2000.0")),
                eq(new BigDecimal("10000.00")), eq(BigDecimal.ZERO), eq(new BigDecimal("10000.00")), eq("INSURANCE")))
                .thenReturn(mockBill);

        // Act
        Bill result = billingService.generateBill(request);

        // Assert
        assertNotNull(result);
        assertEquals(new BigDecimal("10000.00"), result.getTotalAmount());
    }

    @Test
    @DisplayName("TC-08: Idempotent Billing - Return Existing Bill if Already Invoiced")
    void testGenerateBill_AlreadyBilledReturnsExisting() {
        // Arrange
        BillingRequest request = new BillingRequest("APT-20241010-1001", "CASH", "STANDARD");
        when(appointmentDAO.findByAppointmentNumber("APT-20241010-1001")).thenReturn(Optional.of(sampleAppointment));

        Bill existing = new Bill();
        existing.setBillNumber("BILL-EXISTING-999");
        when(billDAO.findByAppointmentNumber("APT-20241010-1001")).thenReturn(Optional.of(existing));

        // Act
        Bill result = billingService.generateBill(request);

        // Assert
        assertNotNull(result);
        assertEquals("BILL-EXISTING-999", result.getBillNumber());
        verify(billDAO, never()).saveBill(anyInt(), any(), any(), any(), any(), any(), any());
    }
}
