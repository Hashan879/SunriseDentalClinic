package com.sunrisedental.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Singleton Pattern Implementation: DatabaseConnection
 * 
 * Provides a globally accessible, single instance for managing standard JDBC 
 * database connections when raw JDBC/DAO connections are required.
 * Implements Double-Checked Locking for high performance and thread safety.
 */
public class DatabaseConnection {

    private static volatile DatabaseConnection instance;
    private static final String URL = "jdbc:mysql://localhost:3306/sunrise_dental_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    // Private constructor prevents direct instantiation
    private DatabaseConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL Driver not found in classpath. Falling back to default drivers: " + e.getMessage());
        }
    }

    /**
     * Global access point for Singleton instance (Thread-safe Double-Checked Locking)
     */
    public static DatabaseConnection getInstance() {
        if (instance == null) {
            synchronized (DatabaseConnection.class) {
                if (instance == null) {
                    instance = new DatabaseConnection();
                }
            }
        }
        return instance;
    }

    /**
     * Obtains a new connection to the MySQL database
     */
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
