package com.sunrisedental.controller;

import com.sunrisedental.model.ApiResponse;
import com.sunrisedental.model.Bill;
import com.sunrisedental.model.BillingRequest;
import com.sunrisedental.service.BillingService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * REST Web Service: Billing & Invoice Generation
 */
@RestController
@RequestMapping("/api/billing")
@CrossOrigin(origins = "*")
public class BillingController {

    @Autowired
    private BillingService billingService;

    @PostMapping("/generate")
    public ResponseEntity<ApiResponse<Bill>> generateBill(@Valid @RequestBody BillingRequest request) {
        try {
            Bill bill = billingService.generateBill(request);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.ok("Bill generated successfully for appointment " + request.getAppointmentNumber(), bill));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ApiResponse.error(e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error generating bill: " + e.getMessage()));
        }
    }

    @GetMapping("/{appointmentNumber}")
    public ResponseEntity<ApiResponse<Bill>> getBill(@PathVariable String appointmentNumber) {
        try {
            Bill bill = billingService.getBillByAppointmentNumber(appointmentNumber);
            return ResponseEntity.ok(ApiResponse.ok("Bill retrieved", bill));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse.error(e.getMessage()));
        }
    }
}
