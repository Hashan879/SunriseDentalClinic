package com.sunrisedental.controller;

import com.sunrisedental.dao.DentistDAO;
import com.sunrisedental.model.ApiResponse;
import com.sunrisedental.model.Dentist;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/dentists")
@CrossOrigin(origins = "*")
public class DentistController {

    @Autowired
    private DentistDAO dentistDAO;

    @GetMapping
    public ResponseEntity<ApiResponse<List<Dentist>>> getAllDentists() {
        List<Dentist> dentists = dentistDAO.findAll();
        return ResponseEntity.ok(ApiResponse.ok("Dentists retrieved", dentists));
    }
}
