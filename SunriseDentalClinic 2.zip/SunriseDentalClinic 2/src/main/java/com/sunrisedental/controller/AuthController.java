package com.sunrisedental.controller;

import com.sunrisedental.model.ApiResponse;
import com.sunrisedental.model.LoginRequest;
import com.sunrisedental.model.User;
import com.sunrisedental.service.AuthService;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * REST Web Service: User Authentication with Session & Cookie Management
 */
@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<User>> login(@Valid @RequestBody LoginRequest request,
                                                  HttpServletRequest httpRequest,
                                                  HttpServletResponse httpResponse) {
        try {
            User user = authService.authenticate(request.getUsername(), request.getPassword());

            // Establish secure server-side HTTP Session
            HttpSession session = httpRequest.getSession(true);
            session.setAttribute("LOGGED_USER", user.getUsername());
            session.setAttribute("USER_ROLE", user.getRole());

            // Set Client Cookie for user identification
            Cookie userCookie = new Cookie("sunrise_user", user.getUsername());
            userCookie.setPath("/");
            userCookie.setMaxAge(3600); // 1 hour session cookie
            userCookie.setHttpOnly(false);
            httpResponse.addCookie(userCookie);

            return ResponseEntity.ok(ApiResponse.ok("Login successful! Welcome " + user.getFullName(), user));
        } catch (SecurityException e) {
            return ResponseEntity.status(401).body(ApiResponse.error(e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<ApiResponse<Void>> logout(HttpServletRequest httpRequest, HttpServletResponse httpResponse) {
        HttpSession session = httpRequest.getSession(false);
        if (session != null) {
            session.invalidate();
        }

        // Expire cookie
        Cookie userCookie = new Cookie("sunrise_user", "");
        userCookie.setPath("/");
        userCookie.setMaxAge(0);
        httpResponse.addCookie(userCookie);

        return ResponseEntity.ok(ApiResponse.ok("Logged out safely."));
    }

    @GetMapping("/current")
    public ResponseEntity<ApiResponse<String>> getCurrentUser(HttpServletRequest httpRequest) {
        HttpSession session = httpRequest.getSession(false);
        if (session != null && session.getAttribute("LOGGED_USER") != null) {
            String username = (String) session.getAttribute("LOGGED_USER");
            String role = (String) session.getAttribute("USER_ROLE");
            return ResponseEntity.ok(ApiResponse.ok("Active session found", username + " (" + role + ")"));
        }
        return ResponseEntity.ok(ApiResponse.error("No active session"));
    }
}
