package com.sunrisedental.controller;

import com.sunrisedental.model.ApiResponse;
import com.sunrisedental.model.Appointment;
import com.sunrisedental.model.AppointmentRequest;
import com.sunrisedental.service.AppointmentService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Web Service: Appointment Management
 */
@RestController
@RequestMapping("/api/appointments")
@CrossOrigin(origins = "*")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    /**
     * Register New Appointment
     */
    @PostMapping
    public ResponseEntity<ApiResponse<Appointment>> registerAppointment(@Valid @RequestBody AppointmentRequest request) {
        try {
            Appointment created = appointmentService.registerAppointment(request);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.ok("Appointment successfully registered with ID: " + created.getAppointmentNumber(), created));
        } catch (IllegalStateException e) {
            // Conflict (e.g. double booking)
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ApiResponse.error(e.getMessage()));
        } catch (IllegalArgumentException e) {
            // Business rule validation failure
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ApiResponse.error(e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to register appointment: " + e.getMessage()));
        }
    }

    /**
     * Display Appointment Details (Search by Appointment Number)
     */
    @GetMapping("/{appointmentNumber}")
    public ResponseEntity<ApiResponse<Appointment>> getAppointmentDetails(@PathVariable String appointmentNumber) {
        try {
            Appointment appt = appointmentService.getAppointmentDetails(appointmentNumber);
            return ResponseEntity.ok(ApiResponse.ok("Appointment details retrieved successfully", appt));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse.error(e.getMessage()));
        }
    }

    /**
     * List all recent appointments
     */
    @GetMapping
    public ResponseEntity<ApiResponse<List<Appointment>>> getAllAppointments() {
        List<Appointment> list = appointmentService.getAllAppointments();
        return ResponseEntity.ok(ApiResponse.ok("Appointments retrieved successfully", list));
    }
}
