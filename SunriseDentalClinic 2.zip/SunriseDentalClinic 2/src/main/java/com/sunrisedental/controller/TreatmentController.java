package com.sunrisedental.controller;

import com.sunrisedental.dao.TreatmentDAO;
import com.sunrisedental.model.ApiResponse;
import com.sunrisedental.model.Treatment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/treatments")
@CrossOrigin(origins = "*")
public class TreatmentController {

    @Autowired
    private TreatmentDAO treatmentDAO;

    @GetMapping
    public ResponseEntity<ApiResponse<List<Treatment>>> getAllTreatments() {
        List<Treatment> treatments = treatmentDAO.findAll();
        return ResponseEntity.ok(ApiResponse.ok("Treatments retrieved", treatments));
    }
}
