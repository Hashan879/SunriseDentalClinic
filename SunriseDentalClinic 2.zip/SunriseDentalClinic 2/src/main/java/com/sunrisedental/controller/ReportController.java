package com.sunrisedental.controller;

import com.sunrisedental.model.ApiResponse;
import com.sunrisedental.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * REST Web Service: Management Reports & Analytics
 */
@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins = "*")
public class ReportController {

    @Autowired
    private ReportService reportService;

    @GetMapping("/daily")
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> getDailySummary() {
        return ResponseEntity.ok(ApiResponse.ok("Daily report retrieved", reportService.getDailySummary()));
    }

    @GetMapping("/revenue")
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> getRevenueSummary() {
        return ResponseEntity.ok(ApiResponse.ok("Revenue report retrieved", reportService.getRevenueSummary()));
    }

    @GetMapping("/kpis")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getKpiMetrics() {
        return ResponseEntity.ok(ApiResponse.ok("Clinic KPIs retrieved", reportService.getClinicKpis()));
    }
}
