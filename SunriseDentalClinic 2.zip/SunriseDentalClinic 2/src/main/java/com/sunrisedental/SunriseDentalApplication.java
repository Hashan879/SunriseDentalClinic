package com.sunrisedental;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main Entry Point for Sunrise Dental Clinic Management System
 * CIS6003 Advanced Programming - Distributed Application
 */
@SpringBootApplication
public class SunriseDentalApplication {

    public static void main(String[] args) {
        SpringApplication.run(SunriseDentalApplication.class, args);
        System.out.println("=================================================");
        System.out.println("  Sunrise Dental Clinic Management System Started");
        System.out.println("  Web Interface: http://localhost:8080");
        System.out.println("  REST Web Services: http://localhost:8080/api");
        System.out.println("=================================================");
    }
}
