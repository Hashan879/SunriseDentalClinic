package com.sunrisedental.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 * DTO for booking a new appointment with strict validation rules
 */
public class AppointmentRequest {

    @NotBlank(message = "Patient name is required and cannot be empty.")
    private String patientName;

    @NotBlank(message = "Patient address is required.")
    private String address;

    @NotBlank(message = "Contact number is required.")
    @Pattern(regexp = "^(0|\\+94)[0-9]{9}$", message = "Invalid phone number format. Must be a valid Sri Lankan phone number (e.g., 0771234567 or +94771234567).")
    private String contactNumber;

    private String email;

    @NotNull(message = "Dentist must be selected.")
    private Integer dentistId;

    @NotNull(message = "Treatment type must be selected.")
    private Integer treatmentId;

    @NotNull(message = "Appointment date is required.")
    private LocalDate appointmentDate;

    @NotNull(message = "Appointment time is required.")
    private LocalTime appointmentTime;

    private String notes;

    public AppointmentRequest() {}

    // Getters and Setters
    public String getPatientName() { return patientName; }
    public void setPatientName(String patientName) { this.patientName = patientName; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public Integer getDentistId() { return dentistId; }
    public void setDentistId(Integer dentistId) { this.dentistId = dentistId; }

    public Integer getTreatmentId() { return treatmentId; }
    public void setTreatmentId(Integer treatmentId) { this.treatmentId = treatmentId; }

    public LocalDate getAppointmentDate() { return appointmentDate; }
    public void setAppointmentDate(LocalDate appointmentDate) { this.appointmentDate = appointmentDate; }

    public LocalTime getAppointmentTime() { return appointmentTime; }
    public void setAppointmentTime(LocalTime appointmentTime) { this.appointmentTime = appointmentTime; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
