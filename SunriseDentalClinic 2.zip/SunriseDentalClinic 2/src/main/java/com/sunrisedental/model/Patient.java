package com.sunrisedental.model;

import java.time.LocalDateTime;

/**
 * Patient Entity
 */
public class Patient {
    private int id;
    private String patientName;
    private String address;
    private String contactNumber;
    private String email;
    private LocalDateTime createdAt;

    public Patient() {}

    public Patient(int id, String patientName, String address, String contactNumber, String email) {
        this.id = id;
        this.patientName = patientName;
        this.address = address;
        this.contactNumber = contactNumber;
        this.email = email;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getPatientName() { return patientName; }
    public void setPatientName(String patientName) { this.patientName = patientName; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
