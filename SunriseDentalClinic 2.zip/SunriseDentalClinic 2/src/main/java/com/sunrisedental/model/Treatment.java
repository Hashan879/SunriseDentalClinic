package com.sunrisedental.model;

import java.math.BigDecimal;

/**
 * Treatment Entity representing catalog offerings
 */
public class Treatment {
    private int id;
    private String treatmentName;
    private String description;
    private BigDecimal baseCost;
    private int estimatedDurationMinutes;

    public Treatment() {}

    public Treatment(int id, String treatmentName, String description, BigDecimal baseCost, int estimatedDurationMinutes) {
        this.id = id;
        this.treatmentName = treatmentName;
        this.description = description;
        this.baseCost = baseCost;
        this.estimatedDurationMinutes = estimatedDurationMinutes;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTreatmentName() { return treatmentName; }
    public void setTreatmentName(String treatmentName) { this.treatmentName = treatmentName; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public BigDecimal getBaseCost() { return baseCost; }
    public void setBaseCost(BigDecimal baseCost) { this.baseCost = baseCost; }

    public int getEstimatedDurationMinutes() { return estimatedDurationMinutes; }
    public void setEstimatedDurationMinutes(int estimatedDurationMinutes) { this.estimatedDurationMinutes = estimatedDurationMinutes; }
}
