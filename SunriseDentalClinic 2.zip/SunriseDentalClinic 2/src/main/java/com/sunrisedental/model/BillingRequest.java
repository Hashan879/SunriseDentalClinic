package com.sunrisedental.model;

import jakarta.validation.constraints.NotBlank;

/**
 * DTO for Bill Generation request
 */
public class BillingRequest {

    @NotBlank(message = "Appointment number is required.")
    private String appointmentNumber;

    private String paymentMethod = "CASH"; // CASH, CARD, INSURANCE

    private String billingCategory = "STANDARD"; // STANDARD, SENIOR, INSURED

    public BillingRequest() {}

    public BillingRequest(String appointmentNumber, String paymentMethod, String billingCategory) {
        this.appointmentNumber = appointmentNumber;
        this.paymentMethod = paymentMethod;
        this.billingCategory = billingCategory;
    }

    public String getAppointmentNumber() { return appointmentNumber; }
    public void setAppointmentNumber(String appointmentNumber) { this.appointmentNumber = appointmentNumber; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }

    public String getBillingCategory() { return billingCategory; }
    public void setBillingCategory(String billingCategory) { this.billingCategory = billingCategory; }
}
