package com.sunrisedental.model;

import java.math.BigDecimal;

/**
 * Dentist Entity
 */
public class Dentist {
    private int id;
    private String name;
    private String specialization;
    private BigDecimal consultationFee;
    private String contactNumber;
    private String email;

    public Dentist() {}

    public Dentist(int id, String name, String specialization, BigDecimal consultationFee, String contactNumber, String email) {
        this.id = id;
        this.name = name;
        this.specialization = specialization;
        this.consultationFee = consultationFee;
        this.contactNumber = contactNumber;
        this.email = email;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getSpecialization() { return specialization; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }

    public BigDecimal getConsultationFee() { return consultationFee; }
    public void setConsultationFee(BigDecimal consultationFee) { this.consultationFee = consultationFee; }

    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
}
