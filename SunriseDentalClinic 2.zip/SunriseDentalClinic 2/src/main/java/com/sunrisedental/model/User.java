package com.sunrisedental.model;

import java.time.LocalDateTime;

/**
 * User Entity for Authentication & Role-Based Access Control
 */
public class User {
    private int id;
    private String username;
    private String passwordHash;
    private String fullName;
    private String role; // ADMIN, RECEPTIONIST, DENTIST
    private String email;
    private boolean active;
    private LocalDateTime createdAt;

    public User() {}

    public User(int id, String username, String passwordHash, String fullName, String role, String email, boolean active) {
        this.id = id;
        this.username = username;
        this.passwordHash = passwordHash;
        this.fullName = fullName;
        this.role = role;
        this.email = email;
        this.active = active;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
