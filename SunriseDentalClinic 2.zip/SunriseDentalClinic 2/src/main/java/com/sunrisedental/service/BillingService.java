package com.sunrisedental.service;

import com.sunrisedental.dao.AppointmentDAO;
import com.sunrisedental.dao.BillDAO;
import com.sunrisedental.model.Appointment;
import com.sunrisedental.model.Bill;
import com.sunrisedental.model.BillingRequest;
import com.sunrisedental.patterns.observer.AppointmentSubject;
import com.sunrisedental.patterns.strategy.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Optional;

/**
 * Service Layer: Billing & Financial Invoicing
 * Implements Strategy Pattern for dynamic billing calculations and Observer for alerts
 */
@Service
public class BillingService {

    @Autowired
    private BillDAO billDAO;

    @Autowired
    private AppointmentDAO appointmentDAO;

    @Autowired
    private AppointmentSubject appointmentSubject;

    public Bill generateBill(BillingRequest request) {
        String apptNumber = request.getAppointmentNumber().trim();

        // 1. Fetch Appointment Details
        Appointment appointment = appointmentDAO.findByAppointmentNumber(apptNumber)
                .orElseThrow(() -> new IllegalArgumentException("Appointment '" + apptNumber + "' not found."));

        // 2. Check if already billed
        Optional<Bill> existingBill = billDAO.findByAppointmentNumber(apptNumber);
        if (existingBill.isPresent()) {
            return existingBill.get();
        }

        // 3. Select Billing Strategy based on Category
        BillingStrategy strategy;
        String category = request.getBillingCategory() != null ? request.getBillingCategory().toUpperCase() : "STANDARD";

        switch (category) {
            case "SENIOR":
                strategy = new SeniorCitizenBillingStrategy();
                break;
            case "INSURED":
                strategy = new InsuredBillingStrategy();
                break;
            case "STANDARD":
            default:
                strategy = new StandardBillingStrategy();
                break;
        }

        BigDecimal treatmentCost = BigDecimal.valueOf(appointment.getTreatmentCost());
        BigDecimal consultationFee = BigDecimal.valueOf(appointment.getConsultationFee());

        // 4. Calculate total using the selected Strategy
        BillingCalculationResult result = strategy.calculate(treatmentCost, consultationFee);

        // 5. Persist Bill record in database
        Bill savedBill = billDAO.saveBill(
                appointment.getId(),
                result.getTreatmentCost(),
                result.getConsultationFee(),
                result.getDiscount(),
                result.getTax(),
                result.getFinalTotal(),
                request.getPaymentMethod() != null ? request.getPaymentMethod() : "CASH"
        );

        // 6. Notify observers of billing event (SMS & Email alerts)
        appointmentSubject.notifyAppointmentBilled(apptNumber, savedBill.getBillNumber(), savedBill.getTotalAmount().doubleValue());

        return savedBill;
    }

    public Bill getBillByAppointmentNumber(String apptNumber) {
        return billDAO.findByAppointmentNumber(apptNumber)
                .orElseThrow(() -> new IllegalArgumentException("No invoice found for appointment " + apptNumber));
    }
}
