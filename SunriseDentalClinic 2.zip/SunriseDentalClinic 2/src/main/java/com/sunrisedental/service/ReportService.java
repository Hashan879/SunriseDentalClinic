package com.sunrisedental.service;

import com.sunrisedental.dao.ReportDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Service Layer: Business Intelligence & Decision Making Reports
 */
@Service
public class ReportService {

    @Autowired
    private ReportDAO reportDAO;

    public List<Map<String, Object>> getDailySummary() {
        return reportDAO.getDailySummaryReport();
    }

    public List<Map<String, Object>> getRevenueSummary() {
        return reportDAO.getRevenueReport();
    }

    public Map<String, Object> getClinicKpis() {
        return reportDAO.getKpiSummary();
    }
}
