package com.sunrisedental.service;

import com.sunrisedental.dao.UserDAO;
import com.sunrisedental.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * Service Layer: Authentication & Authorization
 */
@Service
public class AuthService {

    @Autowired
    private UserDAO userDAO;

    public User authenticate(String username, String password) {
        if (username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            throw new IllegalArgumentException("Username and password cannot be empty.");
        }

        Optional<User> userOpt = userDAO.findByUsername(username.trim());
        if (userOpt.isEmpty()) {
            throw new SecurityException("Invalid username or password.");
        }

        User user = userOpt.get();

        // Check password (supports plain text demo or hashed credentials)
        if (!password.equals(user.getPasswordHash())) {
            throw new SecurityException("Invalid username or password.");
        }

        // Return user without revealing password hash
        user.setPasswordHash(null);
        return user;
    }
}
