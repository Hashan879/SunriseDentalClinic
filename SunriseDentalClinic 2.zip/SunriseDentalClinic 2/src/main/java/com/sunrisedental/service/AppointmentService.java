package com.sunrisedental.service;

import com.sunrisedental.dao.AppointmentDAO;
import com.sunrisedental.dao.DentistDAO;
import com.sunrisedental.dao.TreatmentDAO;
import com.sunrisedental.model.Appointment;
import com.sunrisedental.model.AppointmentRequest;
import com.sunrisedental.model.Dentist;
import com.sunrisedental.model.Treatment;
import com.sunrisedental.patterns.factory.TreatmentFactory;
import com.sunrisedental.patterns.factory.TreatmentItem;
import com.sunrisedental.patterns.observer.AppointmentSubject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Service Layer: Appointment Management
 * Contains Core Business Logic, Double Booking Rules, and Observer Notification
 */
@Service
public class AppointmentService {

    @Autowired
    private AppointmentDAO appointmentDAO;

    @Autowired
    private DentistDAO dentistDAO;

    @Autowired
    private TreatmentDAO treatmentDAO;

    @Autowired
    private AppointmentSubject appointmentSubject;

    /**
     * Registers a new patient appointment with full validation and conflict checks
     */
    public Appointment registerAppointment(AppointmentRequest request) {
        // 1. Business Logic Validation: Ensure appointment date is not in the past
        if (request.getAppointmentDate().isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("Cannot book an appointment for a past date.");
        }

        // 2. Validate Dentist Existence
        Dentist dentist = dentistDAO.findById(request.getDentistId())
                .orElseThrow(() -> new IllegalArgumentException("Selected dentist does not exist in the clinic directory."));

        // 3. Validate Treatment Existence
        Treatment treatment = treatmentDAO.findById(request.getTreatmentId())
                .orElseThrow(() -> new IllegalArgumentException("Selected treatment is not recognized."));

        // 4. Double Booking Prevention: Check if dentist is busy at the exact slot
        boolean hasConflict = appointmentDAO.hasDentistConflict(
                request.getDentistId(),
                request.getAppointmentDate(),
                request.getAppointmentTime()
        );

        if (hasConflict) {
            throw new IllegalStateException("Double Booking Error: " + dentist.getName() +
                    " is already booked for " + request.getAppointmentDate() +
                    " at " + request.getAppointmentTime() + ". Please select another time slot.");
        }

        // 5. Create or Resolve Patient Record
        int patientId = appointmentDAO.findOrCreatePatient(
                request.getPatientName().trim(),
                request.getAddress().trim(),
                request.getContactNumber().trim(),
                request.getEmail() != null ? request.getEmail().trim() : null
        );

        // 6. Leverage Factory Pattern for treatment processing
        TreatmentItem treatmentItem = TreatmentFactory.createTreatment(
                treatment.getId(),
                treatment.getBaseCost(),
                treatment.getEstimatedDurationMinutes()
        );

        // 7. Insert Appointment into Database
        String apptNumber = appointmentDAO.insertAppointment(
                patientId,
                dentist.getId(),
                treatment.getId(),
                request.getAppointmentDate(),
                request.getAppointmentTime(),
                request.getNotes()
        );

        // 8. Fetch complete populated appointment
        Appointment appointment = appointmentDAO.findByAppointmentNumber(apptNumber)
                .orElseThrow(() -> new RuntimeException("Failed to retrieve created appointment."));

        // 9. Observer Pattern: Trigger automated SMS and Email alerts
        appointmentSubject.notifyAppointmentBooked(appointment);

        return appointment;
    }

    /**
     * Search and retrieve complete appointment and patient details
     */
    public Appointment getAppointmentDetails(String appointmentNumber) {
        if (appointmentNumber == null || appointmentNumber.trim().isEmpty()) {
            throw new IllegalArgumentException("Appointment number cannot be empty.");
        }

        return appointmentDAO.findByAppointmentNumber(appointmentNumber.trim())
                .orElseThrow(() -> new IllegalArgumentException("Appointment with number '" + appointmentNumber + "' was not found."));
    }

    /**
     * List all recent appointments
     */
    public List<Appointment> getAllAppointments() {
        return appointmentDAO.findAllRecent();
    }
}
