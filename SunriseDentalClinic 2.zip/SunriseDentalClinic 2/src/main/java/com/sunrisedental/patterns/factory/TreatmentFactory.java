package com.sunrisedental.patterns.factory;

import java.math.BigDecimal;

/**
 * Factory Pattern Implementation: TreatmentFactory
 * 
 * Encapsulates object creation logic for dental treatments based on treatment ID
 * or treatment name. Enables easy extension for new dental procedures without
 * modifying client code (Open/Closed Principle).
 */
public class TreatmentFactory {

    public static TreatmentItem createTreatment(int treatmentId, BigDecimal fallbackCost, int fallbackDuration) {
        switch (treatmentId) {
            case 1:
                return new CleaningTreatment();
            case 3:
                return new RootCanalTreatment();
            case 4:
                return new ExtractionTreatment();
            default:
                BigDecimal cost = fallbackCost != null ? fallbackCost : new BigDecimal("4000.00");
                int duration = fallbackDuration > 0 ? fallbackDuration : 30;
                return new StandardTreatment(cost, duration);
        }
    }

    public static TreatmentItem createTreatmentByName(String name) {
        if (name == null) {
            return new StandardTreatment(new BigDecimal("3500.00"), 30);
        }
        String lower = name.toLowerCase();
        if (lower.contains("clean") || lower.contains("scal")) {
            return new CleaningTreatment();
        } else if (lower.contains("root") || lower.contains("rct")) {
            return new RootCanalTreatment();
        } else if (lower.contains("extract")) {
            return new ExtractionTreatment();
        }
        return new StandardTreatment(new BigDecimal("4500.00"), 45);
    }
}
