package com.sunrisedental.patterns.observer;

import com.sunrisedental.model.Appointment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Subject / Publisher in the Observer Pattern
 */
@Component
public class AppointmentSubject {

    private final List<AppointmentObserver> observers = new ArrayList<>();

    @Autowired
    public AppointmentSubject(SMSNotificationObserver smsObserver, EmailNotificationObserver emailObserver) {
        registerObserver(smsObserver);
        registerObserver(emailObserver);
    }

    public void registerObserver(AppointmentObserver observer) {
        observers.add(observer);
    }

    public void removeObserver(AppointmentObserver observer) {
        observers.remove(observer);
    }

    public void notifyAppointmentBooked(Appointment appointment) {
        for (AppointmentObserver observer : observers) {
            try {
                observer.onAppointmentBooked(appointment);
            } catch (Exception e) {
                System.err.println("Error notifying observer: " + e.getMessage());
            }
        }
    }

    public void notifyAppointmentBilled(String appointmentNumber, String billNumber, double amount) {
        for (AppointmentObserver observer : observers) {
            try {
                observer.onAppointmentBilled(appointmentNumber, billNumber, amount);
            } catch (Exception e) {
                System.err.println("Error notifying observer: " + e.getMessage());
            }
        }
    }
}
