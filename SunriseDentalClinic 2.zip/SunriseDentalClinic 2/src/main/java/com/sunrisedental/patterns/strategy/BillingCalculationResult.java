package com.sunrisedental.patterns.strategy;

import java.math.BigDecimal;

/**
 * Strategy Pattern Result Holder
 */
public class BillingCalculationResult {
    private final BigDecimal treatmentCost;
    private final BigDecimal consultationFee;
    private final BigDecimal discount;
    private final BigDecimal tax;
    private final BigDecimal finalTotal;
    private final String strategyName;

    public BillingCalculationResult(BigDecimal treatmentCost, BigDecimal consultationFee, 
                                    BigDecimal discount, BigDecimal tax, BigDecimal finalTotal, 
                                    String strategyName) {
        this.treatmentCost = treatmentCost;
        this.consultationFee = consultationFee;
        this.discount = discount;
        this.tax = tax;
        this.finalTotal = finalTotal;
        this.strategyName = strategyName;
    }

    public BigDecimal getTreatmentCost() { return treatmentCost; }
    public BigDecimal getConsultationFee() { return consultationFee; }
    public BigDecimal getDiscount() { return discount; }
    public BigDecimal getTax() { return tax; }
    public BigDecimal getFinalTotal() { return finalTotal; }
    public String getStrategyName() { return strategyName; }
}
