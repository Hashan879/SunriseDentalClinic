package com.sunrisedental.patterns.strategy;

import java.math.BigDecimal;

/**
 * Standard Billing Strategy (No discount, default fee structure)
 */
public class StandardBillingStrategy implements BillingStrategy {
    @Override
    public BillingCalculationResult calculate(BigDecimal treatmentCost, BigDecimal consultationFee) {
        BigDecimal discount = BigDecimal.ZERO;
        BigDecimal tax = BigDecimal.ZERO;
        BigDecimal total = treatmentCost.add(consultationFee);
        return new BillingCalculationResult(treatmentCost, consultationFee, discount, tax, total, "Standard Rate");
    }
}
