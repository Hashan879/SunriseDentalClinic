package com.sunrisedental.patterns.observer;

import com.sunrisedental.model.Appointment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Concrete Observer: Dispatches simulated SMS notifications to patients
 */
@Component
public class SMSNotificationObserver implements AppointmentObserver {

    private static final Logger log = LoggerFactory.getLogger(SMSNotificationObserver.class);

    @Override
    public void onAppointmentBooked(Appointment appointment) {
        String msg = String.format("[SMS GATEWAY] To: %s | Dear %s, your appointment %s at Sunrise Dental Clinic is confirmed for %s at %s with %s.",
                appointment.getPatientContact(),
                appointment.getPatientName(),
                appointment.getAppointmentNumber(),
                appointment.getAppointmentDate(),
                appointment.getAppointmentTime(),
                appointment.getDentistName());
        log.info(msg);
        System.out.println(msg);
    }

    @Override
    public void onAppointmentBilled(String appointmentNumber, String billNumber, double amount) {
        String msg = String.format("[SMS GATEWAY] Bill Generated | Apt: %s, Invoice: %s, Paid Amount: LKR %.2f. Thank you for visiting Sunrise Dental Clinic!",
                appointmentNumber, billNumber, amount);
        log.info(msg);
        System.out.println(msg);
    }
}
