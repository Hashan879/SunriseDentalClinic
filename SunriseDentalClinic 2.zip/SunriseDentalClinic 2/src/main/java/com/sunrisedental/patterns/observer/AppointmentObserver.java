package com.sunrisedental.patterns.observer;

import com.sunrisedental.model.Appointment;

/**
 * Observer Interface for Appointment Events (SMS & Email alerts)
 */
public interface AppointmentObserver {
    void onAppointmentBooked(Appointment appointment);
    void onAppointmentBilled(String appointmentNumber, String billNumber, double amount);
}
