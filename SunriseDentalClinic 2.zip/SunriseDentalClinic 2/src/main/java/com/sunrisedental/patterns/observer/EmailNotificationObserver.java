package com.sunrisedental.patterns.observer;

import com.sunrisedental.model.Appointment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Concrete Observer: Dispatches simulated Email notifications to patients
 */
@Component
public class EmailNotificationObserver implements AppointmentObserver {

    private static final Logger log = LoggerFactory.getLogger(EmailNotificationObserver.class);

    @Override
    public void onAppointmentBooked(Appointment appointment) {
        if (appointment.getPatientEmail() != null && !appointment.getPatientEmail().trim().isEmpty()) {
            String msg = String.format("[SMTP MAIL] To: %s | Subject: Booking Confirmation (%s) - Sunrise Dental Clinic | Doctor: %s | Treatment: %s",
                    appointment.getPatientEmail(),
                    appointment.getAppointmentNumber(),
                    appointment.getDentistName(),
                    appointment.getTreatmentName());
            log.info(msg);
            System.out.println(msg);
        }
    }

    @Override
    public void onAppointmentBilled(String appointmentNumber, String billNumber, double amount) {
        String msg = String.format("[SMTP MAIL] Electronic Invoice generated for Appointment %s. Bill Ref: %s, Total: LKR %.2f.",
                appointmentNumber, billNumber, amount);
        log.info(msg);
        System.out.println(msg);
    }
}
