package com.sunrisedental.patterns.factory;

import java.math.BigDecimal;

public class RootCanalTreatment implements TreatmentItem {
    @Override
    public String getCategory() { return "ENDODONTIC"; }
    @Override
    public BigDecimal getBaseCost() { return new BigDecimal("18000.00"); }
    @Override
    public int getDurationMinutes() { return 60; }
    @Override
    public boolean requiresPreMedication() { return true; }
}
