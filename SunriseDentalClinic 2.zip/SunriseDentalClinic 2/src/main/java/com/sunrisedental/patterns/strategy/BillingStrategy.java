package com.sunrisedental.patterns.strategy;

import java.math.BigDecimal;

/**
 * Strategy Interface for Pricing and Discount Calculations
 */
public interface BillingStrategy {
    BillingCalculationResult calculate(BigDecimal treatmentCost, BigDecimal consultationFee);
}
