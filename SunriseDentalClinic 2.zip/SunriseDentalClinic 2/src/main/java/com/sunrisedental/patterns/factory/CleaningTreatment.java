package com.sunrisedental.patterns.factory;

import java.math.BigDecimal;

/**
 * Concrete Products in Factory Pattern
 */
public class CleaningTreatment implements TreatmentItem {
    @Override
    public String getCategory() { return "PREVENTIVE"; }
    @Override
    public BigDecimal getBaseCost() { return new BigDecimal("3000.00"); }
    @Override
    public int getDurationMinutes() { return 30; }
    @Override
    public boolean requiresPreMedication() { return false; }
}
