package com.sunrisedental.patterns.factory;

import java.math.BigDecimal;

public class ExtractionTreatment implements TreatmentItem {
    @Override
    public String getCategory() { return "SURGICAL"; }
    @Override
    public BigDecimal getBaseCost() { return new BigDecimal("5500.00"); }
    @Override
    public int getDurationMinutes() { return 45; }
    @Override
    public boolean requiresPreMedication() { return true; }
}
