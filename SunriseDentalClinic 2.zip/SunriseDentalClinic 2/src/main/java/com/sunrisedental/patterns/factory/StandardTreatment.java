package com.sunrisedental.patterns.factory;

import java.math.BigDecimal;

public class StandardTreatment implements TreatmentItem {
    private final BigDecimal cost;
    private final int duration;

    public StandardTreatment(BigDecimal cost, int duration) {
        this.cost = cost;
        this.duration = duration;
    }

    @Override
    public String getCategory() { return "GENERAL"; }
    @Override
    public BigDecimal getBaseCost() { return cost; }
    @Override
    public int getDurationMinutes() { return duration; }
    @Override
    public boolean requiresPreMedication() { return false; }
}
