package com.sunrisedental.patterns.strategy;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Insured Patient Billing Strategy (Insurance covers 50% of the entire bill)
 */
public class InsuredBillingStrategy implements BillingStrategy {
    @Override
    public BillingCalculationResult calculate(BigDecimal treatmentCost, BigDecimal consultationFee) {
        BigDecimal subtotal = treatmentCost.add(consultationFee);
        BigDecimal discount = subtotal.multiply(new BigDecimal("0.50")).setScale(2, RoundingMode.HALF_UP);
        BigDecimal tax = BigDecimal.ZERO;
        BigDecimal patientCopay = subtotal.subtract(discount);
        return new BillingCalculationResult(treatmentCost, consultationFee, discount, tax, patientCopay, "Insurance Co-Pay (50% Covered)");
    }
}
