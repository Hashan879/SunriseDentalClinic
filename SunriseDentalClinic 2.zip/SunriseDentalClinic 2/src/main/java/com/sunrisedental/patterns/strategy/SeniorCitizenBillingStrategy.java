package com.sunrisedental.patterns.strategy;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Senior Citizen Billing Strategy (Offers 15% discount on consultation fee)
 */
public class SeniorCitizenBillingStrategy implements BillingStrategy {
    @Override
    public BillingCalculationResult calculate(BigDecimal treatmentCost, BigDecimal consultationFee) {
        BigDecimal discount = consultationFee.multiply(new BigDecimal("0.15")).setScale(2, RoundingMode.HALF_UP);
        BigDecimal tax = BigDecimal.ZERO;
        BigDecimal total = treatmentCost.add(consultationFee).subtract(discount);
        return new BillingCalculationResult(treatmentCost, consultationFee, discount, tax, total, "Senior Citizen (15% on Consultation)");
    }
}
