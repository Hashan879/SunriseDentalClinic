package com.sunrisedental.patterns.factory;

import java.math.BigDecimal;

/**
 * Component interface in the Factory Method Pattern
 */
public interface TreatmentItem {
    String getCategory();
    BigDecimal getBaseCost();
    int getDurationMinutes();
    boolean requiresPreMedication();
}
