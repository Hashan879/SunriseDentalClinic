package com.sunrisedental.dao;

import com.sunrisedental.model.Dentist;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class DentistDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private final RowMapper<Dentist> rowMapper = (rs, rowNum) -> {
        Dentist d = new Dentist();
        d.setId(rs.getInt("id"));
        d.setName(rs.getString("name"));
        d.setSpecialization(rs.getString("specialization"));
        d.setConsultationFee(rs.getBigDecimal("consultation_fee"));
        d.setContactNumber(rs.getString("contact_number"));
        d.setEmail(rs.getString("email"));
        return d;
    };

    public List<Dentist> findAll() {
        String sql = "SELECT id, name, specialization, consultation_fee, contact_number, email FROM dentists ORDER BY name ASC";
        return jdbcTemplate.query(sql, rowMapper);
    }

    public Optional<Dentist> findById(int id) {
        String sql = "SELECT id, name, specialization, consultation_fee, contact_number, email FROM dentists WHERE id = ?";
        try {
            return Optional.ofNullable(jdbcTemplate.queryForObject(sql, rowMapper, id));
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }
}
