package com.sunrisedental.dao;

import com.sunrisedental.model.Treatment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class TreatmentDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private final RowMapper<Treatment> rowMapper = (rs, rowNum) -> {
        Treatment t = new Treatment();
        t.setId(rs.getInt("id"));
        t.setTreatmentName(rs.getString("treatment_name"));
        t.setDescription(rs.getString("description"));
        t.setBaseCost(rs.getBigDecimal("base_cost"));
        t.setEstimatedDurationMinutes(rs.getInt("estimated_duration_minutes"));
        return t;
    };

    public List<Treatment> findAll() {
        String sql = "SELECT id, treatment_name, description, base_cost, estimated_duration_minutes FROM treatments ORDER BY id ASC";
        return jdbcTemplate.query(sql, rowMapper);
    }

    public Optional<Treatment> findById(int id) {
        String sql = "SELECT id, treatment_name, description, base_cost, estimated_duration_minutes FROM treatments WHERE id = ?";
        try {
            return Optional.ofNullable(jdbcTemplate.queryForObject(sql, rowMapper, id));
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }
}
