package com.sunrisedental.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * Data Access Object for Management Decision-Making Reports
 */
@Repository
public class ReportDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * Daily appointment summary report
     */
    public List<Map<String, Object>> getDailySummaryReport() {
        String sql = "SELECT * FROM vw_daily_summary LIMIT 30";
        return jdbcTemplate.queryForList(sql);
    }

    /**
     * Financial and Doctor Performance Revenue Report
     */
    public List<Map<String, Object>> getRevenueReport() {
        String sql = "SELECT * FROM vw_revenue_report";
        return jdbcTemplate.queryForList(sql);
    }

    /**
     * Overall Clinic Performance KPI Summary
     */
    public Map<String, Object> getKpiSummary() {
        String sql = "SELECT " +
                     "(SELECT COUNT(*) FROM appointments) AS total_appointments, " +
                     "(SELECT COUNT(*) FROM patients) AS total_patients, " +
                     "(SELECT COUNT(*) FROM appointments WHERE status = 'CONFIRMED') AS pending_appointments, " +
                     "(SELECT COALESCE(SUM(total_amount), 0) FROM bills) AS total_revenue";
        return jdbcTemplate.queryForMap(sql);
    }
}
