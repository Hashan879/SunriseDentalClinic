package com.sunrisedental.dao;

import com.sunrisedental.model.Appointment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.Random;

/**
 * Data Access Object (DAO Pattern): AppointmentDAO
 * Handles all database interactions for appointments and patient registration
 */
@Repository
public class AppointmentDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private final RowMapper<Appointment> enrichedRowMapper = (rs, rowNum) -> {
        Appointment apt = new Appointment();
        apt.setId(rs.getInt("appointment_id"));
        apt.setAppointmentNumber(rs.getString("appointment_number"));
        apt.setPatientName(rs.getString("patient_name"));
        apt.setPatientAddress(rs.getString("patient_address"));
        apt.setPatientContact(rs.getString("contact_number"));
        apt.setPatientEmail(rs.getString("patient_email"));
        apt.setDentistId(rs.getInt("dentist_id"));
        apt.setDentistName(rs.getString("dentist_name"));
        apt.setDentistSpecialization(rs.getString("dentist_specialization"));
        apt.setConsultationFee(rs.getDouble("consultation_fee"));
        apt.setTreatmentId(rs.getInt("treatment_id"));
        apt.setTreatmentName(rs.getString("treatment_name"));
        apt.setTreatmentCost(rs.getDouble("treatment_cost"));
        apt.setAppointmentDate(rs.getDate("appointment_date").toLocalDate());
        apt.setAppointmentTime(rs.getTime("appointment_time").toLocalTime());
        apt.setStatus(rs.getString("status"));
        apt.setNotes(rs.getString("notes"));
        apt.setBillNumber(rs.getString("bill_number"));
        Double billTotal = rs.getDouble("total_amount");
        if (!rs.wasNull()) {
            apt.setBillTotal(billTotal);
        }
        return apt;
    };

    /**
     * Check if a dentist already has a conflicting appointment booked at the same date and time
     */
    public boolean hasDentistConflict(int dentistId, LocalDate date, LocalTime time) {
        String sql = "SELECT COUNT(*) FROM appointments WHERE dentist_id = ? AND appointment_date = ? AND appointment_time = ? AND status != 'CANCELLED'";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, dentistId, Date.valueOf(date), Time.valueOf(time));
        return count != null && count > 0;
    }

    /**
     * Find existing patient by contact number or create new patient record
     */
    public int findOrCreatePatient(String name, String address, String contactNumber, String email) {
        String findSql = "SELECT id FROM patients WHERE contact_number = ? LIMIT 1";
        try {
            Integer existingId = jdbcTemplate.queryForObject(findSql, Integer.class, contactNumber);
            if (existingId != null) {
                // Update latest address & email
                String updateSql = "UPDATE patients SET patient_name = ?, address = ?, email = ? WHERE id = ?";
                jdbcTemplate.update(updateSql, name, address, email, existingId);
                return existingId;
            }
        } catch (EmptyResultDataAccessException ignored) {}

        // Insert new patient
        String insertSql = "INSERT INTO patients (patient_name, address, contact_number, email) VALUES (?, ?, ?, ?)";
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, name);
            ps.setString(2, address);
            ps.setString(3, contactNumber);
            ps.setString(4, email);
            return ps;
        }, keyHolder);

        return keyHolder.getKey().intValue();
    }

    /**
     * Inserts new appointment record
     */
    public String insertAppointment(int patientId, int dentistId, int treatmentId, 
                                    LocalDate date, LocalTime time, String notes) {
        String datePart = date.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        int rand = 1000 + new Random().nextInt(9000);
        String appointmentNumber = "APT-" + datePart + "-" + rand;

        String sql = "INSERT INTO appointments (appointment_number, patient_id, dentist_id, treatment_id, appointment_date, appointment_time, status, notes) " +
                     "VALUES (?, ?, ?, ?, ?, ?, 'CONFIRMED', ?)";

        jdbcTemplate.update(sql, appointmentNumber, patientId, dentistId, treatmentId, Date.valueOf(date), Time.valueOf(time), notes);
        return appointmentNumber;
    }

    /**
     * Search appointment by unique appointment number
     */
    public Optional<Appointment> findByAppointmentNumber(String appointmentNumber) {
        String sql = "SELECT * FROM vw_complete_appointments WHERE appointment_number = ?";
        try {
            Appointment apt = jdbcTemplate.queryForObject(sql, enrichedRowMapper, appointmentNumber.trim());
            return Optional.ofNullable(apt);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    /**
     * Retrieve all appointments ordered by date and time
     */
    public List<Appointment> findAllRecent() {
        String sql = "SELECT * FROM vw_complete_appointments ORDER BY appointment_date DESC, appointment_time DESC LIMIT 100";
        return jdbcTemplate.query(sql, enrichedRowMapper);
    }

    /**
     * Updates appointment status
     */
    public void updateStatus(int appointmentId, String status) {
        String sql = "UPDATE appointments SET status = ? WHERE id = ?";
        jdbcTemplate.update(sql, status, appointmentId);
    }
}
