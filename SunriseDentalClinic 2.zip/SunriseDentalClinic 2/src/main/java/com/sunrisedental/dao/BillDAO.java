package com.sunrisedental.dao;

import com.sunrisedental.model.Bill;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Optional;
import java.util.Random;

/**
 * Data Access Object (DAO Pattern): BillDAO
 * Handles persistence for invoicing and receipts
 */
@Repository
public class BillDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private final RowMapper<Bill> billRowMapper = (rs, rowNum) -> {
        Bill b = new Bill();
        b.setId(rs.getInt("id"));
        b.setBillNumber(rs.getString("bill_number"));
        b.setAppointmentId(rs.getInt("appointment_id"));
        b.setAppointmentNumber(rs.getString("appointment_number"));
        b.setPatientName(rs.getString("patient_name"));
        b.setDentistName(rs.getString("dentist_name"));
        b.setTreatmentName(rs.getString("treatment_name"));
        b.setTreatmentCost(rs.getBigDecimal("treatment_cost"));
        b.setConsultationFee(rs.getBigDecimal("consultation_fee"));
        b.setTaxAmount(rs.getBigDecimal("tax_amount"));
        b.setDiscountAmount(rs.getBigDecimal("discount_amount"));
        b.setTotalAmount(rs.getBigDecimal("total_amount"));
        b.setPaymentMethod(rs.getString("payment_method"));
        b.setPaymentStatus(rs.getString("payment_status"));
        b.setBilledAt(rs.getTimestamp("billed_at").toLocalDateTime());
        return b;
    };

    public boolean isAlreadyBilled(int appointmentId) {
        String sql = "SELECT COUNT(*) FROM bills WHERE appointment_id = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, appointmentId);
        return count != null && count > 0;
    }

    public Bill saveBill(int appointmentId, BigDecimal treatmentCost, BigDecimal consultationFee,
                         BigDecimal discount, BigDecimal tax, BigDecimal total, String paymentMethod) {
        String billNumber = "BILL-" + (System.currentTimeMillis() / 1000) + "-" + (100 + new Random().nextInt(900));

        String sql = "INSERT INTO bills (bill_number, appointment_id, treatment_cost, consultation_fee, tax_amount, discount_amount, total_amount, payment_method, payment_status) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PAID')";

        jdbcTemplate.update(sql, billNumber, appointmentId, treatmentCost, consultationFee, tax, discount, total, paymentMethod);

        // Update appointment status to BILLED
        jdbcTemplate.update("UPDATE appointments SET status = 'BILLED' WHERE id = ?", appointmentId);

        return findByBillNumber(billNumber).orElse(null);
    }

    public Optional<Bill> findByBillNumber(String billNumber) {
        String sql = "SELECT b.*, a.appointment_number, p.patient_name, d.name AS dentist_name, t.treatment_name " +
                     "FROM bills b " +
                     "JOIN appointments a ON b.appointment_id = a.id " +
                     "JOIN patients p ON a.patient_id = p.id " +
                     "JOIN dentists d ON a.dentist_id = d.id " +
                     "JOIN treatments t ON a.treatment_id = t.id " +
                     "WHERE b.bill_number = ?";
        try {
            return Optional.ofNullable(jdbcTemplate.queryForObject(sql, billRowMapper, billNumber));
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    public Optional<Bill> findByAppointmentNumber(String appointmentNumber) {
        String sql = "SELECT b.*, a.appointment_number, p.patient_name, d.name AS dentist_name, t.treatment_name " +
                     "FROM bills b " +
                     "JOIN appointments a ON b.appointment_id = a.id " +
                     "JOIN patients p ON a.patient_id = p.id " +
                     "JOIN dentists d ON a.dentist_id = d.id " +
                     "JOIN treatments t ON a.treatment_id = t.id " +
                     "WHERE a.appointment_number = ?";
        try {
            return Optional.ofNullable(jdbcTemplate.queryForObject(sql, billRowMapper, appointmentNumber));
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }
}
