// Sunrise Dental Clinic - Interactive Web Client Script
const API_BASE = '/api';

let dentistsList = [];
let treatmentsList = [];
let activeUser = null;

document.addEventListener('DOMContentLoaded', () => {
    checkActiveSession();
    loadDentists();
    loadTreatments();
    loadRecentAppointments();
    loadKpiReports();
    setMinAppointmentDate();
});

// Set minimum date to today (cannot book in past)
function setMinAppointmentDate() {
    const today = new Date().toISOString().split('T')[0];
    const dateInput = document.getElementById('appointmentDate');
    if (dateInput) {
        dateInput.min = today;
        dateInput.value = today;
    }
}

// Navigation Tab Switching
function showSection(sectionId) {
    document.querySelectorAll('.content-section').forEach(sec => sec.classList.add('d-none'));
    const target = document.getElementById(sectionId);
    if (target) {
        target.classList.remove('d-none');
    }

    // Update active nav link
    document.querySelectorAll('#mainNavLinks .nav-link').forEach(link => link.classList.remove('active'));
    const clickedLink = Array.from(document.querySelectorAll('#mainNavLinks .nav-link'))
        .find(l => l.getAttribute('onclick') && l.getAttribute('onclick').includes(sectionId));
    if (clickedLink) clickedLink.classList.add('active');

    // Trigger report refresh if entering reports
    if (sectionId === 'reports-section') {
        loadKpiReports();
    }
}

// Alert Message Helper
function showAlert(message, type = 'success') {
    const alertBox = document.getElementById('alertBox');
    const alertMessage = document.getElementById('alertMessage');
    alertBox.className = `alert alert-${type} alert-dismissible fade show shadow-sm`;
    alertMessage.innerHTML = message;
    alertBox.classList.remove('d-none');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function hideAlert() {
    document.getElementById('alertBox').classList.add('d-none');
}

// -------------------------------------------------------------
// Authentication (Login / Logout / Sessions & Cookies)
// -------------------------------------------------------------
async function checkActiveSession() {
    try {
        const res = await fetch(`${API_BASE}/auth/current`);
        const json = await res.json();
        if (json.success && json.data) {
            setLoggedInState(json.data);
        }
    } catch (e) {
        console.log("No active session", e);
    }
}

async function handleLogin(e) {
    e.preventDefault();
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value.trim();

    try {
        const res = await fetch(`${API_BASE}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const json = await res.json();

        if (res.ok && json.success) {
            const user = json.data;
            setLoggedInState(`${user.fullName} (${user.role})`);
            showAlert(`Welcome back, ${user.fullName}!`, 'success');
            const modalEl = document.getElementById('loginModal');
            bootstrap.Modal.getInstance(modalEl)?.hide();
        } else {
            showAlert(json.message || "Invalid login credentials", "danger");
        }
    } catch (err) {
        showAlert("Server connection failed. Is the backend running?", "danger");
    }
}

async function handleLogout() {
    try {
        await fetch(`${API_BASE}/auth/logout`, { method: 'POST' });
        activeUser = null;
        document.getElementById('userInfoBadge').classList.add('d-none');
        document.getElementById('btnLoginModal').classList.remove('d-none');
        document.getElementById('btnLogout').classList.add('d-none');
        showAlert("Logged out safely. Have a great day!", "info");
    } catch (e) {
        console.error(e);
    }
}

function setLoggedInState(userDisplay) {
    activeUser = userDisplay;
    document.getElementById('loggedInUserText').innerText = userDisplay;
    document.getElementById('userInfoBadge').classList.remove('d-none');
    document.getElementById('btnLoginModal').classList.add('d-none');
    document.getElementById('btnLogout').classList.remove('d-none');
}

// -------------------------------------------------------------
// Loading Dropdowns & Fee Calculations
// -------------------------------------------------------------
async function loadDentists() {
    try {
        const res = await fetch(`${API_BASE}/dentists`);
        const json = await res.json();
        if (json.success) {
            dentistsList = json.data;
            const select = document.getElementById('dentistSelect');
            select.innerHTML = '<option value="">-- Select Specialist Dentist --</option>' +
                dentistsList.map(d => `<option value="${d.id}">${d.name} (${d.specialization}) - LKR ${d.consultationFee.toFixed(2)}</option>`).join('');
        }
    } catch (e) {
        console.error("Error loading dentists", e);
    }
}

async function loadTreatments() {
    try {
        const res = await fetch(`${API_BASE}/treatments`);
        const json = await res.json();
        if (json.success) {
            treatmentsList = json.data;
            const select = document.getElementById('treatmentSelect');
            select.innerHTML = '<option value="">-- Select Dental Treatment --</option>' +
                treatmentsList.map(t => `<option value="${t.id}">${t.treatmentName} - LKR ${t.baseCost.toFixed(2)}</option>`).join('');
        }
    } catch (e) {
        console.error("Error loading treatments", e);
    }
}

function updateFeePreview() {
    const dentistId = parseInt(document.getElementById('dentistSelect').value);
    const treatmentId = parseInt(document.getElementById('treatmentSelect').value);

    let dentistFee = 0;
    let treatmentFee = 0;

    const dentist = dentistsList.find(d => d.id === dentistId);
    if (dentist) dentistFee = dentist.consultationFee;

    const treatment = treatmentsList.find(t => t.id === treatmentId);
    if (treatment) treatmentFee = treatment.baseCost;

    document.getElementById('previewDentistFee').innerText = `LKR ${dentistFee.toFixed(2)}`;
    document.getElementById('previewTreatmentFee').innerText = `LKR ${treatmentFee.toFixed(2)}`;
    document.getElementById('previewTotalFee').innerText = `LKR ${(dentistFee + treatmentFee).toFixed(2)}`;
}

// -------------------------------------------------------------
// Register New Appointment
// -------------------------------------------------------------
async function handleAppointmentSubmit(e) {
    e.preventDefault();

    const requestBody = {
        patientName: document.getElementById('patientName').value.trim(),
        contactNumber: document.getElementById('contactNumber').value.trim(),
        address: document.getElementById('patientAddress').value.trim(),
        email: document.getElementById('patientEmail').value.trim() || null,
        dentistId: parseInt(document.getElementById('dentistSelect').value),
        treatmentId: parseInt(document.getElementById('treatmentSelect').value),
        appointmentDate: document.getElementById('appointmentDate').value,
        appointmentTime: document.getElementById('appointmentTime').value,
        notes: document.getElementById('notes').value.trim()
    };

    const submitBtn = document.getElementById('btnSubmitAppt');
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Booking...';

    try {
        const res = await fetch(`${API_BASE}/appointments`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestBody)
        });
        const json = await res.json();

        if (res.ok && json.success) {
            showAlert(`<strong>Success!</strong> Appointment booked! Number: <span class="badge bg-primary fs-6">${json.data.appointmentNumber}</span>. Automated SMS & Email alerts dispatched.`, 'success');
            document.getElementById('appointmentForm').reset();
            updateFeePreview();
            setMinAppointmentDate();
            loadRecentAppointments();
            loadKpiReports();
        } else {
            showAlert(`<strong>Booking Failed:</strong> ${json.message}`, 'danger');
        }
    } catch (err) {
        showAlert("Server connection failed. Could not book appointment.", "danger");
    } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fa-solid fa-check-circle me-1"></i> Confirm & Book Appointment';
    }
}

// -------------------------------------------------------------
// Load Recent Appointments
// -------------------------------------------------------------
async function loadRecentAppointments() {
    try {
        const res = await fetch(`${API_BASE}/appointments`);
        const json = await res.json();
        if (json.success) {
            const listEl = document.getElementById('recentAppointmentsList');
            if (!json.data || json.data.length === 0) {
                listEl.innerHTML = '<div class="p-3 text-center text-muted">No appointments recorded yet.</div>';
                return;
            }

            listEl.innerHTML = json.data.slice(0, 5).map(apt => `
                <div class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-2">
                    <div>
                        <div class="fw-bold text-primary">${apt.appointmentNumber}</div>
                        <div class="text-muted small">${apt.patientName} &bull; ${apt.dentistName}</div>
                        <div class="text-muted small"><i class="fa-regular fa-clock me-1"></i>${apt.appointmentDate} at ${apt.appointmentTime}</div>
                    </div>
                    <span class="badge ${apt.status === 'BILLED' ? 'bg-success' : 'bg-primary'}">${apt.status}</span>
                </div>
            `).join('');
        }
    } catch (e) {
        console.error(e);
    }
}

// -------------------------------------------------------------
// Search & Display Appointment Details
// -------------------------------------------------------------
async function handleSearchAppointment() {
    const apptNum = document.getElementById('searchApptInput').value.trim();
    if (!apptNum) {
        showAlert("Please enter an appointment number to search.", "warning");
        return;
    }

    try {
        const res = await fetch(`${API_BASE}/appointments/${encodeURIComponent(apptNum)}`);
        const json = await res.json();

        if (res.ok && json.success) {
            const apt = json.data;
            document.getElementById('searchResultCard').classList.remove('d-none');
            document.getElementById('resApptNumber').innerText = apt.appointmentNumber;
            document.getElementById('resStatus').innerText = apt.status;
            document.getElementById('resPatientName').innerText = apt.patientName;
            document.getElementById('resContact').innerText = apt.patientContact;
            document.getElementById('resAddress').innerText = apt.patientAddress;
            document.getElementById('resEmail').innerText = apt.patientEmail || 'Not Provided';
            document.getElementById('resDentist').innerText = apt.dentistName;
            document.getElementById('resSpecialization').innerText = apt.dentistSpecialization;
            document.getElementById('resTreatment').innerText = `${apt.treatmentName} (LKR ${apt.treatmentCost.toFixed(2)})`;
            document.getElementById('resDateTime').innerText = `${apt.appointmentDate} at ${apt.appointmentTime}`;
            document.getElementById('resNotes').innerText = apt.notes || 'None';

            // Show or hide Quick Bill button based on status
            const btnQuickBill = document.getElementById('btnQuickBill');
            if (apt.status === 'BILLED') {
                btnQuickBill.innerText = "View Generated Bill";
            } else {
                btnQuickBill.innerText = "Proceed to Billing";
            }
        } else {
            showAlert(`Appointment not found: ${json.message}`, "warning");
            document.getElementById('searchResultCard').classList.add('d-none');
        }
    } catch (e) {
        showAlert("Error connecting to server while searching.", "danger");
    }
}

function proceedToBillFromSearch() {
    const apptNum = document.getElementById('resApptNumber').innerText;
    document.getElementById('billApptNumber').value = apptNum;
    showSection('billing-section');
}

// -------------------------------------------------------------
// Calculate and Generate Bill
// -------------------------------------------------------------
async function handleGenerateBill(e) {
    e.preventDefault();
    const appointmentNumber = document.getElementById('billApptNumber').value.trim();
    const billingCategory = document.getElementById('billingCategory').value;
    const paymentMethod = document.getElementById('paymentMethod').value;

    try {
        const res = await fetch(`${API_BASE}/billing/generate`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ appointmentNumber, billingCategory, paymentMethod })
        });
        const json = await res.json();

        if (res.ok && json.success) {
            const bill = json.data;
            displayReceipt(bill);
            showAlert(`Bill ${bill.billNumber} successfully processed!`, 'success');
            loadRecentAppointments();
            loadKpiReports();
        } else {
            showAlert(`Billing failed: ${json.message}`, "danger");
        }
    } catch (e) {
        showAlert("Server error while generating invoice.", "danger");
    }
}

function displayReceipt(bill) {
    document.getElementById('rcptBillNo').innerText = bill.billNumber;
    document.getElementById('rcptAptNo').innerText = bill.appointmentNumber;
    document.getElementById('rcptDate').innerText = new Date(bill.billedAt).toLocaleString();
    document.getElementById('rcptPatient').innerText = bill.patientName;
    document.getElementById('rcptDentist').innerText = bill.dentistName;
    document.getElementById('rcptPaymentMethod').innerText = bill.paymentMethod;
    document.getElementById('rcptTreatment').innerText = bill.treatmentName;
    document.getElementById('rcptTreatmentCost').innerText = bill.treatmentCost.toFixed(2);
    document.getElementById('rcptConsultationFee').innerText = bill.consultationFee.toFixed(2);
    document.getElementById('rcptDiscount').innerText = `-${bill.discountAmount.toFixed(2)}`;
    document.getElementById('rcptTotal').innerText = `LKR ${bill.totalAmount.toFixed(2)}`;
}

function printReceipt() {
    window.print();
}

// -------------------------------------------------------------
// Management Reports & KPIs
// -------------------------------------------------------------
async function loadKpiReports() {
    try {
        // KPIs
        const kpiRes = await fetch(`${API_BASE}/reports/kpis`);
        const kpiJson = await kpiRes.json();
        if (kpiJson.success && kpiJson.data) {
            const kpi = kpiJson.data;
            document.getElementById('kpiTotalApts').innerText = kpi.total_appointments || 0;
            document.getElementById('kpiTotalPatients').innerText = kpi.total_patients || 0;
            document.getElementById('kpiPendingApts').innerText = kpi.pending_appointments || 0;
            document.getElementById('kpiRevenue').innerText = Number(kpi.total_revenue || 0).toLocaleString('en-US', { minimumFractionDigits: 2 });
        }

        // Revenue Table
        const revRes = await fetch(`${API_BASE}/reports/revenue`);
        const revJson = await revRes.json();
        if (revJson.success && revJson.data) {
            const tbody = document.querySelector('#revenueTable tbody');
            tbody.innerHTML = revJson.data.map(r => `
                <tr>
                    <td><strong>${r.dentist_name}</strong></td>
                    <td class="text-center">${r.total_patients_treated}</td>
                    <td class="text-end fw-bold text-success">${Number(r.total_revenue).toFixed(2)}</td>
                </tr>
            `).join('') || '<tr><td colspan="3" class="text-center text-muted">No revenue data yet</td></tr>';
        }

        // Daily Traffic Table
        const dailyRes = await fetch(`${API_BASE}/reports/daily`);
        const dailyJson = await dailyRes.json();
        if (dailyJson.success && dailyJson.data) {
            const tbody = document.querySelector('#dailyTable tbody');
            tbody.innerHTML = dailyJson.data.map(d => `
                <tr>
                    <td>${d.appointment_date}</td>
                    <td class="text-center">${d.total_appointments}</td>
                    <td class="text-center"><span class="badge bg-success">${d.billed_count}</span></td>
                    <td class="text-center"><span class="badge bg-primary">${d.confirmed_count}</span></td>
                </tr>
            `).join('') || '<tr><td colspan="4" class="text-center text-muted">No appointments recorded</td></tr>';
        }
    } catch (e) {
        console.error("Error loading KPI reports", e);
    }
}
