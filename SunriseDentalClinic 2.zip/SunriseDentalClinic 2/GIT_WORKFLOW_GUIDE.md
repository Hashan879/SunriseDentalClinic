# GitHub Version Control & CI/CD Documentation (Task D Guide)

## 1. Overview
The assessment requires a **public GitHub repository** demonstrating progressive software development across multiple days, branching workflows, pull requests, and automated CI/CD pipeline deployments.

---

## 2. Step-by-Step Git Commands to Initialize Repository

Execute the following commands in terminal inside `/Users/priyadarshanasilva/.gemini/antigravity/scratch/SunriseDentalClinic`:

```bash
# 1. Initialize local repository
git init
git branch -M main

# 2. Add remote repository link (replace with your personal GitHub repo URL)
# Example: https://github.com/your-username/SunriseDentalClinic.git
git remote add origin https://github.com/<your-username>/SunriseDentalClinic.git
```

---

## 3. Recommended Multi-Day Commit History Strategy

To meet the requirement: *"Update it with several versions where modifications are applied each day, that you have applied the new features into which were initially uploaded."*

### Day 1: Project Setup & Database Layer
```bash
git checkout -b setup/database-architecture
git add pom.xml database/ .gitignore
git commit -m "feat(database): initialize relational schema, stored procedures, and triggers"
git checkout main
git merge setup/database-architecture --no-ff -m "merge: incorporate database layer into main"
git push -u origin main
```

### Day 2: Core Domain Entities & DAO Pattern
```bash
git checkout -b feature/domain-and-daos
git add src/main/java/com/sunrisedental/model/ src/main/java/com/sunrisedental/dao/ src/main/java/com/sunrisedental/config/
git commit -m "feat(core): implement domain entities, Singleton DB manager, and DAO layer"
git checkout main
git merge feature/domain-and-daos --no-ff -m "merge: add DAO patterns and entities to main"
git push origin main
```

### Day 3: Business Logic & Design Patterns (Factory, Strategy, Observer)
```bash
git checkout -b feature/design-patterns-service
git add src/main/java/com/sunrisedental/patterns/ src/main/java/com/sunrisedental/service/
git commit -m "feat(services): implement Factory, Strategy, and Observer design patterns with business rules"
git checkout main
git merge feature/design-patterns-service --no-ff -m "merge: integrate design patterns and service layer"
git push origin main
```

### Day 4: Distributed REST Web Services & Session Management
```bash
git checkout -b feature/rest-web-services
git add src/main/java/com/sunrisedental/controller/ src/main/resources/application.properties
git commit -m "feat(api): expose RESTful web service endpoints with session/cookie handling"
git checkout main
git merge feature/rest-web-services --no-ff -m "merge: integrate distributed REST controllers"
git push origin main
```

### Day 5: Presentation Tier (Interactive Web Client)
```bash
git checkout -b feature/interactive-frontend
git add src/main/resources/static/
git commit -m "feat(ui): implement responsive Bootstrap 5 client interface with billing receipt print"
git checkout main
git merge feature/interactive-frontend --no-ff -m "merge: complete presentation tier and UI"
git push origin main
```

### Day 6: Test-Driven Development (TDD) & CI/CD Pipeline
```bash
git checkout -b feature/testing-and-cicd
git add src/test/ .github/workflows/
git commit -m "test(tdd): automated JUnit 5 test suites and GitHub Actions CI/CD pipeline"
git checkout main
git merge feature/testing-and-cicd --no-ff -m "merge: enable automated CI/CD build workflows"
git tag -a v1.0.0 -m "Release v1.0.0 - Production ready Sunrise Dental Clinic system"
git push origin main --tags
```

---

## 4. GitHub Actions CI/CD Verification

1. Once pushed to GitHub, navigate to the **Actions** tab in your repository.
2. The workflow defined in `.github/workflows/maven.yml` will automatically trigger.
3. It will set up Java JDK 17, run all unit tests via `mvn test`, and package the executable JAR.
4. Take a screenshot of the green checkmark (`Build and Test: Passed`) to insert into your assignment report for **Task D**!
